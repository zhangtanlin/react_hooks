import React, { useEffect, useMemo, useRef, useState, } from "react";
import "../resources/css/alter.less";

import Emit from "../libs/eventEmitter";
import ClickBtn from "./ClickBtn";
import Loading from "./Loading";

// alter弹出框
export default () => {
  const [show, setShow] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [hideBtn, setHideBtn] = useState(false);
  const [submitText, setSubmitText] = useState("确认");
  const submitRef = useRef(null);
  const [submitLoading, setSubmitLoading] = useState(false);
  useEffect(() => {
    Emit.on("changeAlter", ({
      title,
      content,
      hideBtn,
      submitText,
      submit,
    }) => {
      setShow(true);
      title && setTitle(title || '');
      content && setContent(content);
      setHideBtn(!!hideBtn);
      submitText && setSubmitText(submitText);
      submitRef.current = submit;
    });
    return () => {
      Emit.off("changeAlter");
    };
  }, []);
  const onClose = () => {
    setShow(false);
  };
  const onSubmit = async () => {
    setSubmitLoading(true);
    try {
      if (submitRef.current) {
        await submitRef.current();
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "执行失败",
      });
    } finally {
      hideSelf();
    }
    setSubmitLoading(false);
  };
  // 关闭弹出框
  const hideSelf = () => {
    setShow(false);
    setTitle("");
    setContent("");
    setHideBtn(false);
    setSubmitText("确认");
    submitRef.current = null;
  };
  return useMemo(() => (
    <div className={`alter ${show ? "show" : "hide"}`}>
      <ClickBtn
        className="alter-layer"
        onTap={onClose}
      />
      <div className="alter-body">
        {title ? (
          <span className="alter-title">
            {title}
          </span>
        ) : <></>}
        {content ? (
          <div className="alter-content">
            {content}
          </div>
        ) : <></>}
        {hideBtn ? (
          <></>
        ) : (
          <div className="alter-btn-box">
            <ClickBtn
              className="alter-btn"
              onTap={onSubmit}
            >
              {submitLoading ? (
                <Loading show overSize={false} size="15" />
              ) : submitText}
            </ClickBtn>
          </div>
        )}
      </div>
    </div>
  ), [
    show,
    title,
    content,
    hideBtn,
    submitText,
    submitLoading,
  ]);
};
