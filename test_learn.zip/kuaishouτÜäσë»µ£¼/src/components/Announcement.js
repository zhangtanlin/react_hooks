import React, { useEffect, useMemo } from "react";
import "../resources/css/announcement.less";

import StackPage from "./StackPage";
import StackStore from "../store/stack";
import ClickBtn from "./ClickBtn";
import App from "./App";

export default props => {
  const { show, content, onClose } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  useEffect(() => { }, [show]);
  // 跳转应用中心
  const handleAppCenter = () => {
    onClose && onClose(false);
    const stackKey = `App-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "App",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <App stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className={`announcement ${show ? "show" : ""}`}>
      <ClickBtn
        className="close_box"
        onTap={() => { onClose && onClose(false); }}
      />
      <div className="announcement-box">
        <div className="top-img" />
        <div className="content">
          <div
            className="text"
            dangerouslySetInnerHTML={{
              __html: content?.replaceAll("\n", "<br/>")
            }}
          />
          <div className="btn_box">
            <ClickBtn
              className="submit_btn light"
              onTap={handleAppCenter}
            >
              应用中心
            </ClickBtn>
            <ClickBtn
              className="submit_btn"
              onTap={() => {
                onClose && onClose(false);
              }}
            >
              我知道了
            </ClickBtn>
          </div>
        </div>
      </div>
    </div>
  ), [show, onClose, content]);
};
