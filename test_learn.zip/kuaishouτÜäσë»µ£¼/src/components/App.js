import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "./ScrollArea";
import HeaderBack from "./Header/HeaderBack";
import ClickBtn from "./ClickBtn";
import Loading from "./Loading";
import Simg from "./Simg";
import Emit from "../libs/eventEmitter";
import { NoData } from "./NoData";
import { BannerAdList } from './Banner';
import { apiGetAppCenter } from "../libs/http";

export default (props) => {
  const { stackKey } = props;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const getData = async () => {
    try {
      const res = await apiGetAppCenter();
      if (res?.status) {
        setData(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求应用失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  const handleDownload = (url) => {
    window.open(url, "_blank");
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title="应用中心"
        right={() => <div style={{ width: "1.5rem" }} />}
      />
      {loading ? (
        <Loading show overSize={false} size={30} />
      ) : data ? (
        <ScrollArea>
          <div className=" public-padding">
            {data?.banner?.length ? (
              <BannerAdList list={data?.banner} noPadding />
            ) : <></>}
            <div className="user-app-list">
              <div className="user-app-list-title">大家都在玩</div>
              {data.apps.map((item, index) => (
                <ClickBtn
                  key={`user-app-list-item-${index}`}
                  className="user-app-list-item"
                  onTap={() => handleDownload(item?.link_url)}
                >
                  <div className="user-app-list-item-head">
                    <Simg src={item?.img_url} />
                  </div>
                  <div className="user-app-list-item-info">
                    <p className="user-app-list-item-title">{item?.title}</p>
                    <p className="user-app-list-item-subtitle">
                      {item?.clicked}次下载
                    </p>
                    <p className="user-app-list-item-descript">
                      {item?.description}
                    </p>
                  </div>
                  <div className="user-app-list-item-active">
                    <div className="user-app-list-item-btn">
                      下载
                    </div>
                  </div>
                </ClickBtn>
              ))}
            </div>
          </div>
        </ScrollArea>
      ) : (
        <NoData />
      )}
    </div>
  ), [loading, data]);
};
