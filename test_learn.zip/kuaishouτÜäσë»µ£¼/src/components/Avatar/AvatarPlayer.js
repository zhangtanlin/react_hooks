import React, { useMemo, useState, } from "react";
import '../../resources/css/avatar/avatar_player.less';

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import StackPage from "../StackPage";
import Info from "../User/Info";
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";
import Emit from "../../libs/eventEmitter";
import { apiSetFollowing } from "../../libs/http";

import iconAddRedMark from "../../resources/img/icon_add_red_mark.png";

/**
 * 视频播放器内的头像
 * @param {function} src 头像地址
 * @param {function} uid 头像用户ID
 * @param {function} isFollow 是否关注此头像
 * @param {function} onInfoPage 跳转头像用户页面
 */
export default (props) => {
  const {
    src,
    uid,
    isFollow = false,
    onInfoPage,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  let attentionBtnClick = true; // 关注按钮是否被点击
  const [isAttention, setIsAttention] = useState(isFollow); // 是否关注
  const handleUserPage = (uid) => {
    if (!uid) return;
    onInfoPage && onInfoPage();
    const tempName = 'Manage';
    const tempStackKey = `Info-${new Date().getTime()}`;
    const tempPage = <Info stackKey={tempStackKey} uid={uid}/>;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  const handleLike = async(uid) => {
    if (!attentionBtnClick || !uid) return;
    try {
      attentionBtnClick = false;
      const tempParams = {
        to_uid: uid,
      };
      const res = await apiSetFollowing(tempParams);
      if (res?.status) {
        setIsAttention(isAttention === 1 ? 0 : 1);
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    attentionBtnClick = true;
  };
  return useMemo(() => (
    <div className="avatar_player_box">
      <ClickBtn
        stopPropagation
        className="avatar"
        onTap={() => handleUserPage(uid)}
      >
        <Simg src={src} />
      </ClickBtn>
      {!isAttention && (
        <ClickBtn
          stopPropagation
          className="follow"
          onTap={() => handleLike(uid)}
        >
          <img src={iconAddRedMark} />
        </ClickBtn>
      )}
    </div>
  ), [src, isAttention, user]);
};
