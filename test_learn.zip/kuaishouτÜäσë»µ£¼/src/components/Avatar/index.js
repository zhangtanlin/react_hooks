import React from "react";
import '../../resources/css/avatar/index.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import Manage from "../User/Info";
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";

/**
 * 公共头像
 * @param [String]   src       头像加密地址
 * @param [Number]   size      头像大小【单位rem】
 * @param [String]   className 盒子类名
 * @param [Number]   uid       用户id
 * @param [function] onTap     点击事件
 */
export default (props) => {
  const {
    src,
    size = 1,
    className,
    uid,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const toUserPage = () => {
    if (!uid) return;
    const tempName = 'Manage';
    const tempStackKey = `Manage-${new Date().getTime()}`;
    const tempPage = <Manage stackKey={tempStackKey} uid={uid}/>;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  return (
    <ClickBtn
      className={`avatar ${className || ""}`}
      style={{
        width: `${size}rem`,
        height: `${size}rem`,
      }}
      onTap={toUserPage}
    >
      <div className="avatar-box">
        <Simg src={src} />
      </div>
    </ClickBtn>
  );
};
