import React, { useMemo } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import '../resources/css/banner.less';

import StackPage from "./StackPage";
import StackStore from "../store/stack";
import ClickBtn from "./ClickBtn";
import Simg from "./Simg";
import Tag from "./Mv/Tag";
import Recharge from "./User/Recharge";
import DiamondRecharge from "./User/DiamondRecharge";

SwiperCore.use([Controller]);

/**
 * banner列表
 * @param {array} props.list 列表
 * @param {array} props.imgStyle 图片样式
 * @param {array} props.style 列表框样式
 * @returns
 */
export const BannerAdList = (props) => {
  const {
    list,
    imgStyle, // {imgStyle : 图片样式}
    style,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");

  // 跳转
  // 0 => '默认处理',
  // 1 => '外部跳转连接',
  // 2 => '内部跳转标签',
  // 3 => '内部跳转连接',
  // 4 => '内部跳转视频详情',
  // 5 => '直接安装App',
  // 6 => '跳转到VIP',
  // 7 => '跳转钻石商城',
  // 8 => '跳转到游戏',
  const handleLink = (item) => {
    const tempType = item?.type || 0; // 跳转类型
    const tempLink = item?.url || ""; // 跳转链接
    const tempSrc = item?.img_url || ""; // 图片地址
    if (!tempSrc) return;
    let tempName = '';
    let tempStackKey = "";
    let tempPage = "";
    if (tempType === 0) {
      return;
    }
    if (tempType === 1 || tempType === 3) {
      window.open(tempLink, "_blank");
      return;
    }
    if (tempType === 2) {
      tempName = 'Tag';
      tempStackKey = `Tag-${new Date().getTime()}`;
      tempPage = <Tag stackKey={tempStackKey} />;
    }
    if (tempType === 4) {
      return;
    }
    if (tempType === 5) {
      return;
    }
    if (tempType === 6) {
      tempName = 'Recharge';
      tempStackKey = `Recharge-${new Date().getTime()}`;
      tempPage = <Recharge stackKey={tempStackKey} />;
    }
    if (tempType === 7) {
      tempName = 'DiamondRecharge';
      tempStackKey = `DiamondRecharge-${new Date().getTime()}`;
      tempPage = <DiamondRecharge stackKey={tempStackKey} />;
    }
    if (tempType === 8) {
      return;
    }
    if (!tempName) return;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };

  return useMemo(() => (
    <div
      className="banner-ad"
      style={style}
    >
      {list?.length ? (
        <Swiper
          className="default-swiper"
          pagination
          loop
          autoplay={{
            delay: 3000,
            disableOnInteraction: false,
          }}
        >
          {list?.map((item, index) => (
            <SwiperSlide key={`banner-ad-${index}`}>
              <ClickBtn
                className="banner-item"
                onTap={() => handleLink(item)}
                style={imgStyle}
              >
                <Simg src={item?.img_url} />
              </ClickBtn>
            </SwiperSlide>
          ))}
        </Swiper>
      ) : <></>}
    </div>
  ), [list]);
};
