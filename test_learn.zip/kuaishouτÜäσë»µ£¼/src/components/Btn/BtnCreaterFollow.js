import React, { useMemo, useState } from "react";
import "../../resources/css/btn/btn_creater_follow.less";

import ClickBtn from '../ClickBtn';
import Emit from "../../libs/eventEmitter";
import {
  apiSetFollowing,
} from '../../libs/http';

// 创作达人-圆形和全半圆形按钮
export default (props) => {
  const {
    active,
    uid,
    theme = false,
    radius = false,
  } = props;
  let attentionBtnClick = true; // 关注按钮是否被点击
  const [attention, setAttention] = useState(active || 0); // 是否关注{0: 未关注,1:已关注}
  const handleAttention = async (uid) => {
    if (!attentionBtnClick || !uid) return;
    try {
      attentionBtnClick = false;
      const tempParams = { to_uid: uid };
      const res = await apiSetFollowing(tempParams);
      if (res?.status) {
        setAttention(attention === 1 ? 0 : 1);
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    attentionBtnClick = true;
  };
  return useMemo(() => (
    <ClickBtn
      className={`
        btn_creater_follow
        ${attention === 1 ? 'active' : ''}
        ${radius ? 'radius' : ''}
        ${theme ? 'theme' : ''}
      `}
      onTap={() => handleAttention(uid)}
    >
      {
        attention === 1 ? <></> : <div className="img_box" />
      }
      {attention === 1 ? '已关注' : '关注'}
    </ClickBtn>
  ), [attention]);
};
