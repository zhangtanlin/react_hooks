import React, { useMemo, useState, } from "react";
import "../../resources/css/btn/btn_player.less";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import Emit from "../../libs/eventEmitter";
import DialogVideoShare from "../Dialog/DialogVideoShare";
import ClickBtn from "../ClickBtn";
import Search from "../Search";
import {
  apiToggleLikeVideo,
} from '../../libs/http';

import iconLikeWhite from "../../resources/img/icon_check_white.png";
import iconLikeRed from "../../resources/img/icon_check_red.png";
import iconShare from "../../resources/img/icon_share.png";
import iconComment from "../../resources/img/icon_msg.png";
import VideoComment from "../Video/VideoComment";

/**
 * 视频播放器-喜欢/未喜欢按钮
 * @param {*} props.id 视频id
 * @param {*} props.status 是否喜欢{0/null: 未喜欢,1: 已喜欢}
 * @param {*} props.number 视频被喜欢的数量
 * @returns
 */
export const BtnPlayerLike = (props) => {
  const {
    id,
    status = 0,
    number = 0,
  } = props;
  const [user] = UserStore.useGlobalState("user");
  // 喜欢按钮是否被点击
  let likeBtnClick = true;
  const [params, setParams] = useState({
    isLike: status, // 是否喜欢
    isNumber: number, // 喜欢数量
  });
  const handle = async (id) => {
    if (!likeBtnClick || !id) return;
    try {
      likeBtnClick = false;
      const tempParam = { id };
      const res = await apiToggleLikeVideo(tempParam);
      if (res?.status) {
        if (params.isLike) {
          setParams((tempParams) => ({
            ...tempParams,
            ...{
              isLike: !tempParams.isLike,
              isNumber: tempParams.isNumber - 1,
            }
          }));
        } else {
          setParams((tempParams) => ({
            ...tempParams,
            ...{
              isLike: !tempParams.isLike,
              isNumber: tempParams.isNumber + 1,
            }
          }));
        }
        Emit.emit(
          "showToast",
          { text: res?.data?.msg || "操作成功" }
        );
      } else {
        Emit.emit(
          "showToast",
          { text: res?.data?.msg || "操作失败" }
        );
      }
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败" });
    }
    likeBtnClick = true;
  };
  return useMemo(() => (
    <ClickBtn
      stopPropagation
      className="btn_player_like"
      onTap={() => handle(id)}
    >
      <img src={params.isLike ? iconLikeRed : iconLikeWhite} />
      <span>{params.isNumber}</span>
    </ClickBtn>
  ), [id, params, user]);
};

/**
 * 视频播放器-分享按钮
 * @returns
 */
export const BtnPlayerShare = (props) => {
  const {
    data,
  } = props;
  const onShare = (data) => {
    Emit.emit(
      "changeDialog",
      {
        _show: true,
        _children: () => (
          <DialogVideoShare data={data} />
        )
      },
    );
  };
  return (
    <ClickBtn
      stopPropagation
      className="btn_player_share"
      onTap={() => onShare(data)}
    >
      <img src={iconShare} />
      <span>分享</span>
    </ClickBtn>
  );
};

/**
 * 视频播放器-评论按钮
 * @returns
 */
export const BtnPlayerComment = (props) => {
  const {
    data,
  } = props;
  const handle = (videoInfo) => {
    Emit.emit(
      "showSheet",
      {
        _show: true,
        _content: () => (
          <VideoComment info={videoInfo} />
        )
      },
    );
  };
  return useMemo(() => (
    <ClickBtn
      stopPropagation
      className="btn_player_comment"
      onTap={() => handle(data)}
    >
      <img src={iconComment} />
      <span>{data?.comment}</span>
    </ClickBtn>
  ), [data]);
};

/**
 * 视频播放器-播放按钮
 * @param {*} props.data 是否显示播放按钮
 * @returns
 */
export const BtnPlayerPlay = () => (
  <div className="btn-player-play" />
);

/**
 * 视频播放器-是否静音按钮
 */
export const BtnPlayerMuted = (props) => {
  const { isOpen, onTap, } = props;
  return useMemo(() => (
    <ClickBtn
      className={`
        btn-player-muted
        ${isOpen ? 'open' : 'close'}
      `}
      onTap={() => {
        if (onTap) onTap();
      }}
    />
  ), [isOpen,]);
  };

/**
 * 视频播放器-搜索按钮
 * @returns
 */
export const BtnPlayerSearch = (props) => {
  const {
    onTap,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = () => {
    onTap && onTap();
    const tempStackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'Manage',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Search stackKey={tempStackKey} />
          </StackPage>
        ),
      },
    });
  };
  return (
    <ClickBtn
      stopPropagation
      className="btn-player-search"
      onTap={() => handle()}
    />
  );
};
