import React, { useMemo } from "react";
import "../../resources/css/btn/btn_sheet_video_buy.less";

import ClickBtn from "../ClickBtn";

/**
 * 底部弹出框-视频购买-立即购买按钮
 * @param {*} props.text 按钮文字
 * @param {*} props.onTap 按钮点击事件
 * @returns
 */
export default (props) => {
  const { text = "立即购买", onTap, } = props;
  return useMemo(() => (
    <ClickBtn
      className="btn_sheet_video_buy"
      onTap={() => {
        onTap && onTap();
      }}
    >
      {text}
    </ClickBtn>
  ), [text,]);
};
