import React, { useMemo } from "react";
import "../../resources/css/btn/btn_video_back.less";

import ClickBtn from "../ClickBtn";
import Emit from "../../libs/eventEmitter";

import iconBackWhite from "../../resources/img/icon_back_white.png";

/**
 * 单独的返回按钮(视频播放器左上角)
 * @param {*} props.stackKey 当前key
 * @param {*} props.isLight 是否亮色调
 * @param {*} props.onTap 点击事件
 * @returns
 */
export default (props) => {
  const {
    stackKey,
    onTap,
    style,
  } = props;
  const handle = () => {
    onTap && onTap();
    Emit.emit(stackKey, stackKey);
  };
  return useMemo(() => (
    <ClickBtn
      className="btn-back"
      style={style}
      onTap={() => handle()}
    >
      <img src={iconBackWhite} />
    </ClickBtn>
  ), []);
};
