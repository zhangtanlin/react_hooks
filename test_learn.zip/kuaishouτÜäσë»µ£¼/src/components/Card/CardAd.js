import React, { useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";
import "../../resources/css/card/card_ad.less";

import ClickBtn from '../ClickBtn';
import Simg from '../Simg';
SwiperCore.use([Controller]);

export const SearchAdCard = (props) => {
  const { list } = props;
  const [controllerSwiper, setControllerSwiper] = useState(null);
  const handle = (url) => {
    if (url) {
      window.open(url, "_blank");
    }
  };
  return useMemo(() => (
    list?.length ? (
      <Swiper
        controller={{ control: controllerSwiper }}
        onSwiper={setControllerSwiper}
      >
        {list.map((item, index) => (
          <SwiperSlide key={`ad-item-${index}`}>
            <ClickBtn
              className="card-search-ad"
              onTap={() => handle(item?.url)}
            >
              <Simg src={item?.img_url} />
            </ClickBtn>
          </SwiperSlide>
        ))}
      </Swiper>
    ) : <></>
  ), [list]);
};
