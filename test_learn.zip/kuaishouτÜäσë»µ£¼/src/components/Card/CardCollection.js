import React, { useMemo } from "react";
import "../../resources/css/card/card_collection.less";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import CollectionDetail from '../Mv/CollectionDetail';
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";

// 默认合集样式
export const CollectionItem = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleDetail = (id) => {
    if (!id) return;
    const tempStackKey = `CollectionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'CollectionDetail',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <CollectionDetail stackKey={tempStackKey} id={id} />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <ClickBtn
      className="collection-item"
      onTap={() => handleDetail(item?.id)}
    >
      <div className="img-box">
        <Simg src={item?.image_url} />
      </div>
      <div className="info">
        <div className="title">{item?.title}</div>
        <div className="subtitle">{item?.like || 0}人喜欢</div>
        <div className="subtitle">共{item?.video_count || 0}集</div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 精选-热门合集
export const CollectionItemHot = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleDetail = (id) => {
    if (!id) return;
    const tempStackKey = `CollectionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'CollectionDetail',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <CollectionDetail
              stackKey={tempStackKey}
              id={id}
              title={item?.title || '合集详情'}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <ClickBtn
      className="collection-hot-item"
      onTap={() => handleDetail(item?.id)}
    >
      <div className="img-box">
        <Simg src={item?.image_full} />
        <div className="img-bottom">
          <div className="title">
            {item?.mv_number || 0}部视频
          </div>
          <div className="tag-box">
            <div className="icon" />
            <div className="tag-name">
              {item?.title}
            </div>
          </div>
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

/**
 * 热榜-热门合集
 * @param item  当前行信息
 * @param num   序号【1开始，如果没有则不显示左上侧序号标记】
 * @param style 样式
 * @description 左右分栏：左侧栏为合集封面，
 *             右侧栏有合集名/创作者/创作者头像/喜欢人数/总集数
 */
export const CollectionItemHotRank = (props) => {
  const { item, num, style, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="collection-item-hot-hank"
      onTap={() => handleDetail()}
      style={{ style }}
    >
      {num && (
        <div className={`mark-box mark-box${num}`}>
          TOP{num}
        </div>
      )}
      <div className="img-box">
        <Simg src={item?.image_url} />
      </div>
      <div className="info-box">
        <div className="title">{item?.title}</div>
        <div className="avatar-row">
          <div className="avatar-box">
            <Simg src={item?.user?.avatar_url} />
          </div>
          <div className="text">
            {item?.user?.nickname}
          </div>
        </div>
        <div className="subtitle">
          {item?.like_count}
          人喜欢·共
          {item?.video_count}
          集
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

/**
 * 合集详情头部显示
 * @param item  当前行信息
 * @description 左右分栏：左侧栏为合集封面，
 *             右侧栏有合集名/创作者/创作者头像/喜欢人数/总集数
 */
export const CollectionItemDetailTop = (props) => {
  const { item, num, style, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="collection-item-detail-top"
      onTap={() => handleDetail()}
      style={{ style }}
    >
      {num && (
        <div className={`mark-box mark-box${num}`}>
          TOP{num}
        </div>
      )}
      <div className="img-box">
        <Simg src={item?.image_url} />
      </div>
      <div className="info-box">
        <div className="title">{item?.title}</div>
        <div className="avatar-row">
          <div className="avatar-box">
            <Simg src={item?.user?.avatar_url} />
          </div>
          <div className="text">
            {item?.user?.nickname}
          </div>
        </div>
        <div className="subtitle">
          {item?.like_count}
          人喜欢·共
          {item?.video_count}
          集
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 合集-发现列表-推荐
export const CardCollectionFind = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="card-collection-find"
      onTap={handleDetail}
    >
      <div className="mark">合集</div>
      <div className="img-box">
        <Simg src={item?.bgUrl} />
      </div>
      <div className="info-box">
        <div className="title">
          #{item?.title}
        </div>
        <div className="subtitle">
          {item?.desc}
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};
