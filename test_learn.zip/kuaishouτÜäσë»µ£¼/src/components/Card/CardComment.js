import React, { useMemo, useState } from "react";
import '../../resources/css/card/card_comment.less';

import ClickBtn from '../ClickBtn';
import Simg from "../Simg";
import Emit from "../../libs/eventEmitter";
import { apiToggleLikeComments } from '../../libs/http';

import iconChecked from '../../resources/img/icon_check_red.png';
import iconUnChecked from '../../resources/img/icon_check_gray.png';

/**
 * 视频-评论行
 * @param {*} props.onPause 点击头像
 */
export const CardComment = (props) => {
  const {
    item,
    onAvatar,
    showClickBtn = true,
  } = props;
  let likeBtnClick = true; // 喜欢按钮是否被点击
  const [isLike, setIsLike] = useState(item?.hasLike);
  const handleManage = () => {
    onAvatar && onAvatar();
  };
  const handleLike = async (id) => {
    if (!likeBtnClick || !id) return;
    try {
      likeBtnClick = false;
      const tempParam = { id };
      const res = await apiToggleLikeComments(tempParam);
      if (res?.status) {
        setIsLike(!isLike);
        Emit.emit(
          "showToast",
          { text: res?.msg || res?.data?.msg || "评论成功" }
        );
      } else {
        Emit.emit(
          "showToast",
          { text: res?.msg || res?.data?.msg || "评论失败" }
        );
      }
    } catch (error) {
      Emit.emit("showToast", { text: "请求失败" });
    }
    likeBtnClick = true;
  };
  return useMemo(() => (
    <div className="card-comment">
      <ClickBtn
        className="avatar-box"
        onTap={() => handleManage(item?.id)}
      >
        <Simg src={item?.user?.thumb} />
      </ClickBtn>
      <div className="info">
        <div className="title">{item?.user?.nickname}</div>
        <div className="subtitle">{item?.createdAtStr}</div>
        <div className="text">{item?.comment}</div>
      </div>
      {showClickBtn ? (
        <ClickBtn
          className="active"
          onTap={() => handleLike(item?.id)}
        >
          <img src={isLike ? iconChecked : iconUnChecked} />
          {item?.likes || 0}
        </ClickBtn>
      ) : <></>}
    </div>
  ), [item, isLike]);
};
