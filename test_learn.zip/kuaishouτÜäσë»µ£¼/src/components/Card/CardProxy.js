import React, { useMemo } from "react";
import '../../resources/css/card/card_proxy.less';

import ClickBtn from "../ClickBtn";

// 代理列表
export const CardProxy = (props) => {
  const { item, onTap } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="card-proxy"
      onTap={() => handleDetail()}
    >
      <div className="left">
        <div className="title">
          {item?.nickname}
        </div>
        <div className="subtitle">
          {item?.created_at}
        </div>
      </div>
      <div className="right">
        {item?.money}
      </div>
    </ClickBtn>
  ), [item]);
};
