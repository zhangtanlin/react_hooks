import React, { useMemo } from "react";
import '../../resources/css/card/card_rank.less';

import ClickBtn from "../ClickBtn";
import Simg from "../Simg";
import Avatar from "../Avatar";

// 搜索页-发现选项卡-人气榜单
export const CardRankFind = (props) => {
  const {
    item,
    onTap,
  } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="card-rank-search"
      onTap={() => handleDetail()}
    >
      <div className="inner-box">
        <div className="img-box">
          <Simg src={item?.background} />
        </div>
        <div className="info">
          <Avatar src={item?.thumb} />
          <div className="title">
            {item?.nickname}
          </div>
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};

// 搜索页-选项卡-热播榜/热购榜共用
export const CardRankSale = (props) => {
  const {
    item,
    onTap,
  } = props;
  const handleDetail = () => {
    onTap && onTap();
  };
  return useMemo(() => (
    <ClickBtn
      className="card-rank-sale"
      onTap={() => handleDetail()}
    >
      <div className="img-box">
        <Simg src={item?.thumbImg} />
      </div>
      <div className="info">
        <div className="title">
          {item?.title}
        </div>
        <div className="user-info">
          <div className="avatar-box">
            <Avatar src={item?.user?.thumb} size=".75" />
          </div>
          <div className="text">
            {item?.user?.nickname}
          </div>
        </div>
        <div className="statistics">
          <div className="icon" />
          <div className="text">
            {item?.like}
          </div>
        </div>
      </div>
    </ClickBtn>
  ), [item]);
};
