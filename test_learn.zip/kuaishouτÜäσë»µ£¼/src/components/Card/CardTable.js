import React from "react";
import '../../resources/css/card/card_table.less';

// 表格头部
export const CardTableHeader = (props) => {
  const { headerList, } = props;
  return (
    <div className="card-table-item is-header">
      {headerList?.length ?
        headerList?.map((item, index) => (
          <div
            key={`item-${index}`}
            className="item"
          >
            {item?.name}
          </div>
        )) : <></>
      }
    </div>
  );
};

// 表格内容
export const CardTable = (props) => {
  const { item, headerList, } = props;
  return (
    <div className="card-table-item">
      {headerList?.length ? (
        headerList?.map((obj, index) => (
          <div
            key={`item-${index}`}
            className="item"
          >
            {item[obj.value] || ''}
          </div>
        ))) : <></>
      }
    </div>
  );
};

