import React, { useMemo } from "react";
import '../../resources/css/card/card_tag.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ClickBtn from "../ClickBtn";
import TagList from '../List/Tag';
import Simg from "../Simg";
import TagDetail from "../Mv/TagDetail";

// 标签-视频详情
export const TagItem = (props) => {
  const { text } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  return useMemo(() => (
    <ClickBtn
      className="tag-item"
      onTap={() => {
        const stackKey = `TagList-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "TagList",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <TagList stackKey={stackKey} tag={text} />
              </StackPage>
            ),
          },
        });
      }}
    >
      {text}
    </ClickBtn>
  ), [text]);
};

// 搜索页标签
export const ItemTagSearch = (props) => {
  const { item, onTap } = props;
  const handle = (item) => {
    onTap && onTap(item);
  };
  return (
    <ClickBtn
      className="tag-search"
      onTap={() => handle(item)}
    >
      {item}
    </ClickBtn>
  );
};

// 搜索页热门标签
export const ItemTagSearchHot = (props) => {
  const { index, item, onTap } = props;
  const handle = (item) => {
    onTap && onTap(item);
  };
  return (
    <ClickBtn
      className={`tag-item-hot ${index <= 3 ? 'red' : ''}`}
      onTap={() => handle(item)}
    >
      <div className="index">{index}</div>
      {item}
      <div className="mark">热</div>
    </ClickBtn>
  );
};

// 视频页-热门标签列表项
export const TagItemMvHot = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleDetail = (tagName) => {
    if (!tagName) return;
    const tempStackKey = `CollectionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'CollectionDetail',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <TagDetail
              stackKey={tempStackKey}
              tag={tagName}
            />
          </StackPage>
        ),
      },
    });
  };
  return (
    <ClickBtn
      className="tag-item-mv-hot"
      onTap={() => handleDetail(item?.name)}
    >
      <div className="img-box">
        <Simg src={item?.img_url_full} />
        <div className="img-inner-box">
          <div className="icon" />
          <div className="text">
            #{item?.name}
          </div>
        </div>
      </div>
    </ClickBtn>
  );
};

// 视频播放器-标签
export const CardTagPlayer = (props) => {
  const { item, onTap, } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handleDetail = (tagName) => {
    if (!tagName) return;
    onTap && onTap();
    const tempStackKey = `CollectionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'CollectionDetail',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <TagDetail
              stackKey={tempStackKey}
              tag={tagName}
            />
          </StackPage>
        ),
      },
    });
  };
  return (
    <ClickBtn
      stopPropagation
      className="card-tag-player"
      onTap={() => handleDetail(item)}
    >
      #{item}
    </ClickBtn>
  );
};
