import React, { useMemo, useState } from "react";
import "../../resources/css/card/card_user.less";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ClickBtn from '../ClickBtn';
import Simg from '../Simg';
import Info from "../User/Info";
import Emit from "../../libs/eventEmitter";
import iconAdd from '../../resources/img/icon_add.png';
import Avatar from "../Avatar";
import BtnCreaterFollow from "../Btn/BtnCreaterFollow";
import { apiSetFollowing } from '../../libs/http';

import iconDiamond from "../../resources/img/icon_diamond.png";

// 搜索页-用户行【带关注按钮/粉丝/作品/跳转详情】
export const SearchUserItem = (props) => {
  const { item } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  let attentionBtnClick = true; // 关注按钮是否被点击
  const [attention, setAttention] = useState(item?.is_attention || 0); // 是否关注{0: 未关注,1:已关注}
  const handleManage = (uid) => {
    if (!uid) return;
    const tempName = 'Info';
    const tempStackKey = `Info-${new Date().getTime()}`;
    const tempPage = <Info stackKey={tempStackKey} uid={uid} />;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  const handleAttention = async (uid) => {
    if (!attentionBtnClick || !uid) return;
    try {
      attentionBtnClick = false;
      const tempParams = { to_uid: uid };
      const res = await apiSetFollowing(tempParams);
      if (res?.status) {
        setAttention(attention === 1 ? 0 : 1);
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作成功",
          time: 3000
        });
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || "操作失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    attentionBtnClick = true;
  };
  return useMemo(() => (
    <ClickBtn
      className="user-attention-item"
      onTap={() => handleManage(item?.uid)}
    >
      <div className="avatar-box">
        <Simg src={item?.user?.cover_thumb_url} />
      </div>
      <div className="info">
        <div className="title">{item?.nickname || ""}</div>
        <div className="descript">{item?.person_signnatrue || ""}</div>
        <div className="statistics-box">
          粉丝：
          <span className="number">{item?.fans_count || 0}</span>
          作品：
          <div className="number">{item?.videos_count || 0}</div>
        </div>
      </div>
      <ClickBtn
        className={`btn ${attention === 1 ? 'active' : ''}`}
        onTap={() => handleAttention(item?.uid)}
      >
        {
          attention === 1 ? '已关注' : (
            <>
              <img src={iconAdd} />
              关注
            </>
          )
        }
      </ClickBtn>
    </ClickBtn>
  ), [attention]);
};

// 创作者达人-排行榜列表项
export const UserCreateItem = (props) => {
  const { type, item, index } = props;
  // 根据序号设置icon
  const setIconByIndex = (index) => {
    let tempClass = '';
    let tempText = '';
    if (index === 0) {
      tempClass = 'first';
    }
    if (index === 1) {
      tempClass = 'second';
    }
    if (index === 2) {
      tempClass = 'third';
    }
    if (index > 2 && index < 9) {
      tempText = `0${index + 1}`;
    }
    if (index >= 9) {
      tempText = index + 1;
    }
    return (
      <div className={`icon ${tempClass}`}>
        {tempText}
      </div>
    );
  };
  const setDesc = () => {
    switch (type) {
      case 1:
        return `作品数量：${item?.videos_count || 0}`;
      case 2:
        return `收益：${item?.votes || 0}`;
      default:
        return `获得点赞数：${item?.likes_count || 0}`;
    }
  };
  return (
    <div className="user-create-item">
      {setIconByIndex(index)}
      <Avatar
        src={item?.avatar_url}
        uid={item?.uid}
      />
      <div className="info">
        <div className="title">
          {item?.nickname}
        </div>
        <div className="descript">
          {setDesc()}
        </div>
      </div>
      <BtnCreaterFollow
        active={item?.is_attention}
        uid={item?.uid}
      />
    </div>
  );
};

// 用户-信息列表
export const UserInfoItem = (props) => {
  const { item, index } = props;
  return useMemo(() => (
    <div className="user-info-item">
      <Avatar
        src={item?.avatar_url || item?.thumb}
        uid={item?.uid}
      />
      <div className="info">
        <div className="title">
          <span>{item?.nickname}</span>
          {!item?.level ? (
            <div className="diamonds-box">
              <img src={iconDiamond} />
              <span>{item?.level}</span>
            </div>
          ) : <></>}
        </div>
        <div className="descript">
          {item?.person_signnatrue || '这个家伙什么都没留下'}
        </div>
        {item?.fans_count ? (
          <div className="descript">
            `粉丝：${item?.fans_count}`
          </div>
        ) : <></>}
      </div>
      <BtnCreaterFollow
        theme
        active={item?.is_attention}
        uid={item?.uid}
      />
    </div>
  ), [index, item]);
};

// 设置页面用户操作列表
export const CardUserSet = (props) => {
  const { item } = props;
  const handleDetail = () => {
    item?.onTap && item?.onTap();
  };
  return (
    <ClickBtn
      className="card-user-set"
      onTap={() => handleDetail()}
    >
      <div className="left">
        <div className="icon" />
        {item?.name}
      </div>
      <div className={`
        right
        ${item?.status ? '' : 'icon-hide'}
      `}>
        {item?.text}
      </div>
    </ClickBtn>
  );
};
