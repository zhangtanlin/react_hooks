import React from "react";
import "../resources/css/click_btn.less";

// 点击事件
export default props => {
  const {
    onTap,
    children,
    className,
    stopPropagation,
    style,
  } = props;
  return (
    <div
      className={`click_btn ${className}`}
      style={style}
      onClick={(e) => {
        if (stopPropagation) {
          e?.stopPropagation();
        }
        onTap && onTap(e);
      }}
    >
      {children}
    </div>
  );
};
