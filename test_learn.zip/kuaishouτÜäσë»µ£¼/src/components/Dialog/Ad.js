import React, { useMemo, useState, } from "react";
import "../../resources/css/dialog/ad.less";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import ClickBtn from "../ClickBtn";
import Simg from "../Simg";
import Recharge from "../User/Recharge";
import DiamondRecharge from "../User/DiamondRecharge";
import Tag from "../Mv/Tag";

/**
 * 广告弹出框
 * @param {string} props.imgUrl 弹出框图片地址
 * @param {string} props.imgLink 弹出框点击跳转地址
 * @param {string} props.type 类型{0:'默认处理',1:'外部跳转连接',2'内部跳转标签',3:'内部跳转连接',4:'内部跳转视频详情',5:'直接安装App',6:'跳转到VIP',7:'跳转金币商城',8:'跳转到游戏',}
 */
export default (props) => {
  const { imgUrl, imgLink, type, } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [show, setShow] = useState(true);
  const handleLink = () => {
    if (!imgLink) return;
    let tempName = '';
    let tempStackKey = "";
    let tempPage = "";
    if (type === 1 || type === 3) {
      window.open(imgLink, "_blank");
      return;
    }
    if (type === 2) {
      tempName = 'Tag';
      tempStackKey = `Tag-${new Date().getTime()}`;
      tempPage = <Tag stackKey={tempStackKey} />;
    }
    if (type === 4) {
      return;
    }
    if (type === 5) {
      return;
    }
    if (type === 6) {
      tempName = 'Recharge';
      tempStackKey = `Recharge-${new Date().getTime()}`;
      tempPage = <Recharge stackKey={tempStackKey} />;
    }
    if (type === 7) {
      tempName = 'DiamondRecharge';
      tempStackKey = `DiamondRecharge-${new Date().getTime()}`;
      tempPage = <DiamondRecharge stackKey={tempStackKey} />;
    }
    if (type === 8) {
      return;
    }
    if (!tempName) return;
    setShow(false);
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className={`ad-pop ${show ? "show" : ""}`}>
      <ClickBtn
        className="close_box"
        onTap={() => {
          setShow(false);
        }}
      />
      <div className="content-box">
        <ClickBtn
          className="img-box"
          onTap={() => handleLink()}
        >
          <Simg src={imgUrl} />
        </ClickBtn>
        <ClickBtn
          className="close_btn"
          onTap={() => {
            setShow(false);
          }}
        />
      </div>
    </div>
  ), [imgUrl, imgLink, show]);
};
