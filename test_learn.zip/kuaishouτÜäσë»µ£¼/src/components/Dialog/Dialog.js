import React, { useEffect, useMemo, useState } from "react";
import Emit from "../../libs/eventEmitter";
import "../../resources/css/dialog/index.less";

export default () => {
  const [show, setShow] = useState(false);
  const [children, setChildren] = useState(<></>);

  useEffect(() => {
    const handleDialog = ({
      _show,
      _children,
    }) => {
      if (_show !== null) {
        setShow(_show);
      }
      if (_children) {
        setChildren(_children);
      }
    };
    Emit.on("changeDialog", handleDialog);
    return () => {
      Emit.off("changeDialog", handleDialog);
    };
  }, []);
  return useMemo(() => (
    <div
      className={`
        dialog_scaleLayer
        ${show ? 'dialog_scale-in' : 'dialog_scale-out'}
      `}
    >
      <div
        className="dialog_scaleLayer-close"
        onClick={() => {
          setShow(false);
        }}
      />
      <div className="dialog_scaleLayer-body">
        {children}
      </div>
    </div>
  ), [show, children]);
};
