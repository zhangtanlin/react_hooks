import React, { useMemo, useState, useEffect, useRef, } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "../../resources/css/video/video_slide.less";

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import StackPage from "../StackPage";
import Emit from "../../libs/eventEmitter";
import VideoLong from "../Video/VideoLong";
import ScrollVertical from "../Scroll/ScrollVertical";
import ClickBtn from "../ClickBtn";
import AvatarPlayer from "../Avatar/AvatarPlayer";
import SheetVideoBuy from "../Sheet/SheetVideoBuy";
import VideoPlayerSmall from "../Video/VideoPlayerSmall";
import LoadingCircle from "../Loading/LoadingCircle";
import { ListTagPlayer } from "../List/Tag";
import { apiGetFeatured } from "../../libs/http";
import { AlertVip } from "../Card/CardAlert";
import {
  BtnPlayerSearch,
  BtnPlayerLike,
  BtnPlayerShare,
  BtnPlayerComment,
} from "../Btn/BtnPlayer";

import bgVideo from "../../resources/img/bg_video.png";
import videoDetailIcon from "../../resources/img/icon_play_small_white.png";
import coinIcon from "../../resources/img/icon_diamond_yellow.png";

// 精选
export default (props,) => {
  const { isVisible, } = props;
  const [user] = UserStore.useGlobalState("user");
  const [stacks] = StackStore.useGlobalState("stacks");
  const [init, setInit] = useState(false);
  const [loading, setLoading] = useState(true);
  const playerRef = useRef();
  const [params, setParams] = useState({
    page: 1, // 页码
    limit: 5, // 每页显示的条数
    isAll: false, // 是否已加载全部列表
  });
  const [data, setData] = useState([]); // 列表数据
  const [paramsPlay, setParamsPlay] = useState({
    url: '', // 视频播放地址
    currentIndex: 0, // 当前展示的序列号
  });
  const [pause, setPause] = useState(false); // 视频是否暂停
  const [isFirst, setIsFirst] = useState(true); // 因为这里video需要手动执行一次点击，之后才能自动播放，这里进行判定
  const [canPlay, setCanPlay] = useState(false); // 因为这里video需要手动执行一次点击，之后才能自动播放，这里进行判定
  const getData = async () => {
    if (params?.isAll) return;
    try {
      const res = await apiGetFeatured(params);
      console.log('列表', params, res);
      if (res?.status) {
        const tempData = res?.data || [];
        const tempVideoUrl = res?.data[0].playURL || '';
        if (params?.page === 1) {
          setData(tempData);
          setParamsPlay((tempParams) => ({
            ...tempParams,
            ...{
              url: tempVideoUrl,
              currentIndex: 0,
            }
          }));
        } else {
          setData([...data, ...tempData]);
        };
        if (!tempData?.length) {
          setParams({ ...params, isAll: true });
        };
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      };
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    };
    setLoading(false);
  };

  // 监听界面显示隐藏
  useEffect(() => {
    if (isVisible) {
      setInit(true);
    } else {
      setInit(false);
    };
    setLoading(true);
  }, [isVisible]);

  // 监听是否初始化
  // useEffect(() => {
  //   if (init) {
  //     setParams({
  //       page: 1,
  //       limit: 5,
  //       isAll: false,
  //     });
  //     setLoading(true);
  //   }
  // }, [init,]);

  // 监听参数和已经初始化=>请求数据
  useEffect(() => {
    if (init) {
      getData();
    } else {
      setParamsPlay((tempParams) => ({
        ...tempParams,
        ...{
          url: '',
          currentIndex: 0,
        }
      }));
    }
  }, [params, init]);

  // 播放/暂停方法
  const handlePause = async (state = false) => {
    if (!playerRef?.current) return;
    console.log('视频播放地址', paramsPlay?.url);
    if (state) {
      console.log('暂停')
      playerRef?.current?.pause();
      return;
    }
    try {
      console.log('播放')
      await playerRef?.current?.play();
    } catch (error) {
      console.log('异步播放错误', error)
      Emit.emit("showToast", {
        text: "异步播放错误",
      });
    }
  }

  // 监听是否暂停
  // useEffect(() => {
  //   console.log('外部监听暂停', pause, isFirst);
  //   if (!playerRef?.current || isFirst) return;
  //   if (pause) {
  //     handlePause(false);
  //   } else {
  //     handlePause(true);
  //   }
  // }, [pause, ]);

  // 短视频播放器
  const ShortPlayer = () => (
    <div className="feature-video-player">
      {paramsPlay?.url ? (
        <VideoPlayerSmall
          autoPlay
          loop
          videoRef={playerRef}
          src={paramsPlay?.url}
          onPause={() => {
            console.log('外部暂停方法',)
            setPause(true);
          }}
          onPlay={() => {
            console.log('外部播放方法',)
            setPause(false);
          }}
          onCanPlay={() => {
            setCanPlay(true);
          }}
        />
      ) : <></>}
    </div>
  );

  // 短视频swiper
  const ShortSwiper = () => (
    <div className="feature-swiper">
      {data?.length ? (
        <Swiper
          className="default-swiper"
          noSwipingClass="swiper-no-swiping"
          direction="vertical"
          initialSlide={0}
          onSlideChange={(e) => {
            setParamsPlay((tempParams) => ({
              ...tempParams,
              ...{
                url: data[e?.activeIndex].playURL,
                currentIndex: e?.activeIndex,
              },
            }));
            if (e?.activeIndex === data?.length - 2) {
              setParams({
                ...params,
                page: params.page + 1,
              })
            }
          }}
        >
          {data?.map((item, index) => (
            <SwiperSlide key={`video-slide-${index}`}>
              {ShortSlide(item)}
            </SwiperSlide>
          ))}
        </Swiper>
      ) : <></>}
    </div>
  );

  // 短视频slider
  const ShortSlide = (item) => (
    <ClickBtn
      className="video-slide"
      onTap={() => {
        console.log('canPlay', canPlay);
        if (!canPlay) {
          Emit.emit("showToast", {
            text: "视频努力加载中",
          });
          return;
        }
        // console.log('点击播放/暂停:', pause);
        // console.log('点击播放/暂停-第一次:', isFirst);
        // 这一行很重要,因为video自动播放的问题,第一次播放是手动执行播放
        console.log('点击', pause, isFirst);
        if (isFirst) {
          handlePause(false);
          setIsFirst(false);
          return;
        }
        // setPause(!pause);
        handlePause(!pause)
      }}
    >
      <div className="video-slide-info">
        <div className="video-slide-left">
          {item?.tags?.length > 0 ? (
            <ListTagPlayer
              list={item?.tags}
              onTap={() => {
                // setPause(true);
                handlePause(true)
              }}
            />
          ) : <></>}
          <div className="name">
            @{item?.user?.nickname}
          </div>
          <p className="title">
            {item?.title}
          </p>
          <ClickBtn
            className="bottom"
            stopPropagation
            onTap={() => handleLongVideo(item)}
          >
            {!!item?.coins && (
              <div className="coin">
                <img src={coinIcon} />
                {item?.coins}
              </div>
            )}
            {item?.hasLongVideo ? (
              <div className="time">
                <span>
                  <img src={videoDetailIcon} />
                  {user?.isVip ? "观看完整版" : "预览10秒,充值VIP观看完整版"}
                </span>
                {(
                  item?.duration &&
                  item?.duration > 10 &&
                  item?.durationStr != 0
                ) ? (
                  <span>{item?.durationStr}</span>
                ) : <></>}
              </div>
            ) : <></>}
          </ClickBtn>
        </div>
        <div className="video-slide-right">
          <AvatarPlayer
            src={item?.user?.thumb}
            uid={item?.user?.uid}
            isFollow={item?.isFollowed}
            onInfoPage={() => {
              // setPause(true);
              handlePause(true)
            }}
          />
          <BtnPlayerLike
            id={item?.id}
            status={item?.isLiked}
            number={item?.like}
          />
          <BtnPlayerComment
            data={item}
          />
          <BtnPlayerShare
            data={item}
          />
        </div>
      </div>
    </ClickBtn>
  );

  // 跳转长视频
  const handleLongVideo = (videoInfo) => {
    if (!videoInfo?.id) return;
    // setPause(true);
    handlePause(true)
    // 已经购买+vip观看免费视频
    if (
      videoInfo?.hasBuy || (
      user?.isVV &&
      videoInfo?.coins === 0)
    ) {
      const stackKey = `VideoLong-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "VideoLong",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <VideoLong
                stackKey={stackKey}
                id={videoInfo?.id}
              />
            </StackPage>
          ),
        },
      });
      return;
    }
    // 钻石视频
    if (videoInfo?.coins > 0) {
      Emit.emit("showSheet", {
        _show: true,
        _content: (
          <SheetVideoBuy
            videoInfo={videoInfo}
            onSuccess={() => {
              let tempList = list;
              if (tempList?.length) {
                tempList.map((item, index) => {
                  if (index === paramsPlay.currentIndex) {
                    item.hasBuy = true;
                  }
                })
              }
              setList(tempList);
            }}
          />
        ),
        _contentStyle: {
          background: "transparent",
        },
      });
      return;
    }
    // 免费视频
    if (
      videoInfo?.coins === 0 &&
      !user?.isVV
    ) {
      Emit.emit(
        "changeDialog",
        {
          _show: true,
          _children: () => (
            <AlertVip />
          )
        },
      );
      return;
    }
  };

  return useMemo(() => (
    <div
      className={`
        positioned-container black
        ${isVisible ? 'visible' : 'hide'}
      `}
      style={{
        background: `center/cover no-repeat url("${bgVideo}")`,
      }}
    >
      {loading ? (
        <LoadingCircle show />
      ) : (
        <>
          {/* 搜索按钮 */}
          <BtnPlayerSearch
            onTap={() => {
              // setPause(true);
              handlePause(true)
            }}
          />
          {/* 播放器和轮播 */}
          <div className="feature-content">
            {ShortPlayer()}
            {ShortSwiper()}
          </div>
          {/* 广告 */}
          {(
            data?.length > 0 &&
            data[0].hotAds?.length > 0
          ) ? (
            <ScrollVertical
              list={data[0].hotAds}
              height={1.36}
              type={1}
              onTap={() => {
                // setPause(true);
                handlePause(true)
              }}
            />
          ) : <></>}
        </>
      )}
    </div>
  ), [
    isVisible,
    loading,
    data,
    paramsPlay,
    pause,
    isFirst,
    canPlay,
  ]);
};
