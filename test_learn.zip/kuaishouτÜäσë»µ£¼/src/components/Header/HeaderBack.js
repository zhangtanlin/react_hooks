import React from "react";
import '../../resources/css/header/header_back.less';

import Emit from "../../libs/eventEmitter";

import iconBackWhite from "../../resources/img/icon_back_white.png";
import iconBackBlack from "../../resources/img/icon_back_black.png";
import ClickBtn from "../ClickBtn";

export default (props) => {
  const {
    stackKey,
    left, // 左侧块（方法）
    leftIconIsLight, // 左侧是否使用浅色图标
    center, // 中部块（方法）
    title, // 中部文字
    right, // 右侧块（方法）
    rightBtn, // 右侧按钮块（方法）
    fixed = false, // 是否透明浮动在顶部
    style, // 全局样式
  } = props;

  return (
    <div
      className={`
        back-header
        ${leftIconIsLight ? 'white' : 'black'}
        ${fixed ? 'fixed' : ''}
      `}
      style={style}
    >
      {/* 左侧 */}
      {
        left ? left() : (
          <ClickBtn
            className="back-header-left"
            stopPropagation
            onTap={() => {
              Emit.emit(stackKey, stackKey);
            }}
          >
            <div className="back-header-left-back">
              <img
                src={
                  leftIconIsLight ?
                  iconBackWhite :
                  iconBackBlack
                }
              />
            </div>
          </ClickBtn>
        )
      }
      {/* 中部 */}
      {
        center ? center() : (
          <div className="back-header-title">
            {title}
          </div>
        )
      }
      {/* 右侧 */}
      {
        right ? right() : (
          <div className="back-header-right">
            <div className="back-header-right-box">
              {rightBtn ? rightBtn() : <></>}
            </div>
          </div>
        )
      }
    </div>
  );
};
