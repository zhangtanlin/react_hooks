import React, { useMemo, } from "react";
import "../../resources/css/header/header_search.less";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ClickBtn from "../ClickBtn";
import Search from "../Search";

// 搜索头部
export default () => {
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = () => {
    const stackKey = `Search-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "Search",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Search stackKey={stackKey} />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <ClickBtn
      className="header-search"
      onTap={() => handle()}
    >
      <div className="icon" />
      <div className="input-box">
        <div className="icon" />
        <div className="input">快手成年版,分享幸福生活~</div>
      </div>
      <div className="btn-box" />
    </ClickBtn>
  ), []);
};
