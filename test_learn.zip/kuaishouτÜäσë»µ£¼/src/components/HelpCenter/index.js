import React, { useEffect, useState, useMemo } from 'react';
import "../../resources/css/help/help_center.less";

import BackHead from '../Header/HeaderBack';
import ScrollArea from '../ScrollArea';
import ClickBtn from '../ClickBtn';
import StackPage from '../StackPage';
import StackStore from '../../store/stack';
import Service from './Service';
import Loading from '../Loading';
import Const from '../../libs/const';
import Emit from '../../libs/eventEmitter';
import { NoData } from '../NoData';
import { apiGetHelper } from '../../libs/http';

// 帮助中心
export default props => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState('stacks');
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const getData = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const res = await apiGetHelper(params);
      if (res?.status) {
        const tempData = res?.data || [];
        if (params?.page === 1) {
          setData(tempData);
        } else {
          setData([...data, ...tempData]);
        }
        if (!tempData?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  // 跳转在线客服
  const handleService = () => {
    const stackKey = `Service-${new Date().getTime()}`;
    StackStore.dispatch({
      type: 'push',
      payload: {
        name: 'Service',
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Service stackKey={stackKey} />
          </StackPage>
        )
      }
    });
  }
  return (
    <div className="positioned-container">
      <BackHead
        stackKey={stackKey}
        title={Const.titleHelpCenter}
      />
      <div className="full-column">
        {useMemo(() => (
          loading ? (
            <Loading show overSize={false} />
          ) : (
            data?.length ? (
              <ScrollArea
                loadingMore={loadingMore}
                onScrollEnd={nextPage}
              >
                {data?.map((item, index) => (
                  <div
                    key={`user-help-item${index}`}
                    className="help-center-item"
                  >
                    <div className='mark'>
                      <span className="text">Q{index + 1}</span>
                    </div>
                    <div className="info">
                      <div className="title">{item?.question}</div>
                      <div className="text">{item?.answer}</div>
                    </div>
                  </div>
                ))}
              </ScrollArea>
            ) : <NoData />
          )
        ), [loading, data, loadingMore])}
      </div>
      <ClickBtn
        className="help-center-btn"
        onTap={() => handleService()}
      >
        无法解决？联系客服
      </ClickBtn>
    </div>
  );
};
