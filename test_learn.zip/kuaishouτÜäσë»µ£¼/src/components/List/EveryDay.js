import React, { useMemo } from "react";
import '../../resources/css/list/every_day.less';

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import VideoShort from "../Video/VideoShort";
import {
  VideoItem,
} from "../Card/CardVideo";

// 创作达人-头部横向滚动列表
export const EveryDayList = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    const tempStackKey = `CollectionDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'CollectionDetail',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      list?.map((item, index) => (
        <div
          key={`every-day-box-${index}`}
          className="every-day-box"
        >
          <div className="title">
            {item?.info?.title}
          </div>
          <div className="public-column3">
            {item?.list?.length ? item?.list?.map((o, i) => (
              <VideoItem
                key={`everyday-item-${i}`}
                item={o}
                onTap={() => {
                  handle(item?.list, i);
                }}
              />
            )) : <></>}
          </div>
        </div>
      ))
    ) : <></>
  ), [list]);
};
