import React, { useMemo } from "react";
import '../../resources/css/list.less';

import { CardComment } from "../Card/CardComment";

// 视频播放器评论列表
export const ListComment = (props) => {
  const { list } = props;
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.map((item, index) => (
          <div key={`CardComment-${index}`}>
            <CardComment
              item={item}
            />
            {item?.child?.length ? (
              <div style={{ paddingLeft: '1.5rem' }}>
                {item?.child?.map((obj, i) => (
                  <CardComment
                    key={`CardComment-child-${i}`}
                    showClickBtn={false}
                    item={obj}
                  />
                ))}
              </div>
            ) : <></>}
          </div>
        ))}
      </div>
    ) : <></>
  ), [list]);
};
