import React, { useMemo } from "react";
import '../../resources/css/list.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import TagDetail from "../Mv/TagDetail";
import VideoShort from "../Video/VideoShort";
import ClickBtn from "../ClickBtn";
import {
  CardVideoOnly,
  VideoItemSearch,
} from "../Card/CardVideo";
import {
  CardRankFind,
  CardRankSale,
} from "../Card/CardRank";

// import iconListTitleTrophy from "../../resources/img/icon_list_title_trophy.png"
import iconListTitleHeart from "../../resources/img/icon_list_title_heart.png"

// 发现
export const ListSearchFind = (props) => {
  const { list, listOther } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  const handleMore = (tag) => {
    if (!tag) return;
    const stackKey = `TagDetail-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: "TagDetail",
        element: (
          <StackPage
            stackKey={stackKey}
            key={stackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <TagDetail stackKey={stackKey} tag={tag} />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <>
      {/* <div className="public-list-title">
        <div className="icon">
          <img src={iconListTitleTrophy} />
        </div>
        <div className="title">人气榜单</div>
      </div>
      {listOther?.length ? (
        <div className="public-column2">
          {listOther?.map((item, index) => (
            <CardRankFind
              key={`CardRankFind-${index}`}
              item={item}
              onTap={handle}
            />
          ))}
        </div>
      ) : <></>} */}
      <div className="public-list-title">
        <div className="icon">
          <img src={iconListTitleHeart} />
        </div>
        <div className="title">发现精彩</div>
      </div>
      {list?.length ? (
        <div className="public-column1">
          {list?.map((item, index) => (
            <div key={`ListSearchFind-${index}`}>
              <ClickBtn
                className="public-list-title-between"
                onTap={() => handleMore(item?.name)}
              >
                <div className="left">{item?.name}</div>
                <div className="right">查看更多</div>
              </ClickBtn>
              {item?.list?.length ? (
                <div className="public-column3">
                  {item?.list?.map((obj, i) => (
                    <CardVideoOnly
                      key={`CardVideoOnly-${i}`}
                      item={obj}
                      onTap={() => handle(item?.list, i)}
                    />
                  ))}
                </div>
              ) : <></>}
            </div>
          ))}
        </div>
      ) : <></>}
    </>
  ), [list, listOther]);
};

// 最新上传
export const ListSearchUpload = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <div className="public-column2">
        {list?.map((item, index) => (
          <VideoItemSearch
            hidePrice
            key={`VideoItemSearch-${index}`}
            item={item}
            onTap={() => handle(list, index)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};

// 搜索页-选项卡-热播榜
export const ListSearchPlay = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.map((item, index) => (
          <CardRankSale
            key={`CardRankSale-${index}`}
            index={index}
            item={item}
            onTap={() => handle(list, index)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};

// 搜索页-选项卡-热购榜
export const ListSearchSale = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <div className="public-column1">
        {list?.map((item, index) => (
          <CardRankSale
            key={`CardRankSale-${index}`}
            index={index}
            item={item}
            onTap={() => handle(list, index)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};
