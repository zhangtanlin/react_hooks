import React from "react";
import '../../resources/css/list.less';

import {
  CardTableHeader,
  CardTable,
} from "../Card/CardTable";

// 公共表格
export const ListTable = (props) => {
  const { isHeader = false, headerList, list, } = props;
  return (
    isHeader ? (
      <CardTableHeader
        isHeader={isHeader}
        headerList={headerList}
      />
    ) : (
      list?.length ? (
        list?.map((item, index) => (
          <CardTable
            key={`CardTable-${index}`}
            headerList={headerList}
            item={item}
          />
        ))
      ) : <></>
    )
  );
};
