import React, { useMemo } from "react";
import '../../resources/css/list.less';

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import VideoShort from "../Video/VideoShort";
import VideoLong from "../Video/VideoLong";
import Collection from "../Mv/Collection";
import New from "../Mv/New";
import { ScrollItem } from "../Card/CardScroll";
import { CardCollectionFind } from "../Card/CardCollection";
import {
  VideoItemSearch,
  CardFindNew,
  VideoCollection,
  VideoItemHotRank,
  VideoItem,
} from "../Card/CardVideo";

// 创作达人-头部横向滚动列表
export const CreaterScrollerList = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    list?.length ? (
      <div className="list-horizontal">
        {list?.map((item, index) => (
          <ScrollItem
            key={`ScrollItem-${index}`}
            item={item}
            onTap={() => handle(list, index)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};

// 搜索/up主专场推荐-视频列表
export const ListVideoSearch = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    list?.length ? (
      <div className="public-column2">
        {list?.map((item, index) => (
          <VideoItemSearch
            key={`VideoItemSearch-${index}`}
            item={item}
            onTap={() => handle(list, index)}
          />
        ))}
      </div>
    ) : <></>
  ), [list]);
};

// 发现-瀑布流
export const ListFind = (props) => {
  const { listRecommend, list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  const handleCollection = () => {
    const tempStackKey = `Collection-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'Collection',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <Collection
              stackKey={tempStackKey}
            />
          </StackPage>
        ),
      },
    });
  }
  const handleNew = () => {
    const tempStackKey = `New-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'New',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <New stackKey={tempStackKey} />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <div className="public-column2-Waterfalls">
      {listRecommend?.map((item, index) => {
        switch (item?.type) {
          case 'newest':
            return (
              <div
                key={`CardFindNew-${index}`}
                className="item"
              >
                <CardFindNew
                  item={item}
                  onTap={() => handleNew()}
                />
              </div>
            );
          case 'topic':
            return (
              <div
                key={`CardCollectionFind-${index}`}
                className="item"
              >
                <CardCollectionFind
                  item={item}
                  onTap={() => handleCollection()}
                />
              </div>
            );
          default:
            return (<></>);
        }
      })}
      {list?.map((item, index) => (
        <div
          key={`VideoItemSearch-${index}`}
          className="item"
        >
          <VideoItemSearch
            item={item}
            hidePrice
            onTap={() => handle(list, index)}
          />
        </div>
      ))}
    </div>
  ), [list]);
};

// 合集详情-视频列表
export const ListCollectionDetail = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <div className="public-column1">
      {list?.map((item, index) => (
        <VideoCollection
          key={`VideoCollection-${index}`}
          item={item}
          onTap={() => handle(list, index)}
        />
      ))}
    </div>
  ), [list]);
};

// 标签详情-视频列表
export const ListTagVideoDetail = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <div className="public-column2">
      {list?.map((item, index) => (
        <VideoItemSearch
          key={`VideoItemSearch-${index}`}
          hidePrice
          item={item}
          onTap={() => handle(list, index)}
        />
      ))}
    </div>
  ), [list]);
};

// 热门视频-排行榜
export const ListHotVideoRank = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    <div className="public-column1">
      {list?.map((item, index) => (
        <VideoItemHotRank
          key={`VideoItemHotRank-${index}`}
          hidePrice
          item={item}
          num={index + 1}
          onTap={() => handle(list, index)}
        />
      ))}
    </div>
  ), [list]);
};

// 视频列表
export const ListVideoInfo = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <div className="public-column3">
      {list?.map((item, index) => (
        <VideoItem
          key={`VideoItem-${index}`}
          item={item}
          onTap={() => handle(list, index)}
        />
      ))}
    </div>
  ), [list]);
};

// 本人视频列表（跳转的是长视频）
export const ListVideoMysef = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoLong
              stackKey={tempStackKey}
              id={list[index].id}
            />
          </StackPage>
        ),
      },
    });
  }
  return useMemo(() => (
    <div className="public-column3">
      {list?.map((item, index) => (
        <VideoItem
          key={`VideoItem-${index}`}
          item={item}
          onTap={() => handle(list, index)}
        />
      ))}
    </div>
  ), [list]);
};
