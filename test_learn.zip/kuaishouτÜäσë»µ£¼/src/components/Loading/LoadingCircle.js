import React from "react";
import "../../resources/css/loading/loading_circle.less";

// 原型的loading
export default (props) => {
  const {
    type = "normal",
    text = "",
    show,
    overSize = false,
  } = props;

  if (!show) {
    return "";
  }
  if (type != "normal") {
    return (
      <div className="loading-circle">
        <span className="circle-animeted" />
      </div>
    );
  }
  return (
    <div className={overSize ? "loading" : "loading-circle-in-page"}>
      <div className="loading">
        <span className="circle-animeted" />
      </div>
      <span>{text}</span>
    </div>
  );
};
