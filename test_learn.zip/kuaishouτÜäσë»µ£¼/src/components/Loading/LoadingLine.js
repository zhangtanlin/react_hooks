import React from "react";
import "../../resources/css/loading/loading_line.less";

// 加载中-线条
export default () => (
  <div className="loading-line">
    <div className="animate-line"/>
  </div>
);
