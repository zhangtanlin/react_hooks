import React from "react";
import "../../resources/css/loading/loading_video.less";

export default (
  <div className="videoLoading">
    <div className="skCircleFade">
      {(() => {
        const ary = [];
        for (let i = 0; i < 12; i++) {
          ary.push(<div className="skCircleFadeDot" key={`video-loading-${i}`} />);
        }
        return ary;
      })()}
    </div>
  </div>
);
