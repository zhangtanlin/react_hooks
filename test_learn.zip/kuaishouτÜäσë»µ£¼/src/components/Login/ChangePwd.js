import React, { useRef, } from "react";

import ClickBtn from '../ClickBtn';
import HeaderBack from "../Header/HeaderBack";
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { apiUpdatePwd, } from '../../libs/http.js';

// 修改密码
export default (props) => {
  const { stackKey } = props;
  const oldPwdRef = useRef(null); // 旧密码
  const newPwdRef = useRef(null); // 新密码
  const verifyPwdRef = useRef(null); // 确认密码
  const handleSubmit = async () => {
    const tempOld = oldPwdRef?.current?.value || '';
    const tempNew = newPwdRef?.current?.value || '';
    const tempVerify = verifyPwdRef?.current?.value || '';
    const reg = /^\s*$/g;
    if (reg.test(tempOld)) {
      Emit.emit("showToast", {
        text: "旧密码不能为空",
        time: 3000
      });
      return;
    }
    if (reg.test(tempNew)) {
      Emit.emit("showToast", {
        text: "密码不能为空",
        time: 3000
      });
      return;
    }
    if (reg.test(tempVerify)) {
      Emit.emit("showToast", {
        text: "请确认新密码",
        time: 3000
      });
      return;
    }
    if (tempNew !== tempVerify) {
      Emit.emit("showToast", {
        text: "新密码和确认密码不一致",
        time: 3000
      });
      return;
    }
    try {
      const tempParam = {
        oldPassword: tempOld,
        password: tempNew,
      };
      const res = await apiUpdatePwd(tempParam);
      if (res?.status) {
        oldPwdRef.current.value = '';
        newPwdRef.current.value = '';
        verifyPwdRef.current.value = '';
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交成功",
          time: 3000
        });
        window.location.reload();
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "提交失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };
  return (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleChangePwd}
      />
      <div className="public-padding">
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请输入旧密码"
            ref={oldPwdRef}
          />
        </div>
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请输入新密码"
            ref={newPwdRef}
          />
        </div>
        <div className="user-withdraw-input">
          <input
            type="text"
            placeholder="请确认新密码"
            ref={verifyPwdRef}
          />
        </div>
        <ClickBtn
          className="user-public-btn"
          onTap={() => handleSubmit()}
        >
          提交
        </ClickBtn>
      </div>
    </div>
  );
};
