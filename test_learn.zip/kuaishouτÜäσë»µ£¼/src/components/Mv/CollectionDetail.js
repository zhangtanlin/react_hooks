import React, { useEffect, useState, useMemo } from "react";
import "../../resources/css/collection.less";

import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import Simg from "../Simg";
import Emit from "../../libs/eventEmitter";
import { NoData } from '../NoData';
import { ListCollectionDetail } from "../List/Video";
import {
  apiGetCollectionDetail,
} from '../../libs/http';

/**
 * 合集详情
 * @param {string | number} props.id 合集id
 */
export default (props) => {
  const { stackKey, id, title } = props;
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState({}); // 合集信息
  const [data, setData] = useState([]); // 合集列表
  const getData = async () => {
    try {
      const tempParam = { topic_id: id };
      const res = await apiGetCollectionDetail(tempParam);
      if (res?.status) {
        if (res?.data?.info) {
          setInfo(res?.data?.info);
        }
        if (res?.data?.list) {
          setData(res?.data?.list);
        }
      } else {
        Emit.emit("showToast", {
          text: res?.data?.msg || res?.msg || "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={title}
        leftIconIsLight
        fixed
      />
      {loading ? (
        <Loading show />
      ) : (
        <>
          <div className="collection-detail-header">
            <Simg src={info?.image_full} />
          </div>
          <div className="collection-detail-content">
            {data?.length ? (
              <ScrollArea>
                <ListCollectionDetail
                  list={data}
                />
              </ScrollArea>
            ) : <NoData />}
          </div>
        </>
      )}
    </div>
  ), [title, loading, data, info]);
};
