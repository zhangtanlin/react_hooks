import React, { useEffect, useState, useMemo } from "react";

import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Emit from "../../libs/eventEmitter";
import Loading from "../Loading";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { ListFind } from "../List/Video";
import {
  apiFindIndexRecommend,
  apiFindIndex,
} from '../../libs/http';

// 发现
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    limit: 6,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [dataRecommend, setDataRecommend] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      if (params?.page === 1) {
        const redRecommend = await apiFindIndexRecommend();
        if (redRecommend?.status) {
          setDataRecommend(redRecommend?.data || []);
        } else {
          Emit.emit("showToast", {
            text: "请求推荐列表失败",
            time: 3000
          });
        }
      }
      const res = await apiFindIndex(params);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data);
        } else {
          setData([...data, ...res?.data || []]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleFind}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <div className="public-padding">
            {data?.length ? (
              <ListFind
                listRecommend={dataRecommend}
                list={data}
              />
            ) : (
              <NoData />
            )}
          </div>
        </ScrollArea>
      )}
    </div>
  ), [loading, data, dataRecommend, loadingMore]);
};
