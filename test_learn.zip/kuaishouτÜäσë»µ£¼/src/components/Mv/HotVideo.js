import React, { useEffect, useState, useMemo, useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Simg from '../Simg';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import VideoShort from "../Video/VideoShort";
import { NoData } from '../NoData';
import { TabsTwo } from '../Tab';
import { ListHotVideoRank } from "../List/Video";
import {
  apiGetHotRank,
  apiGetHotLike,
  apiGetHotSale,
} from '../../libs/http';
SwiperCore.use([Controller]);

/**
 * 视频热榜
 * @param {number} type {0/null: 热门点赞,1: 热门购买,}
 */
export default (props) => {
  const { stackKey, type } = props;
  const contentRef = useRef(null); // 外部滚动盒子
  const tabRef = useRef(null); // 内部选项卡盒子
  const [backHeaderShow, setHeaderBackShow] = useState(true);
  // 上拉吸顶
  useEffect(() => {
    if (!contentRef.current || !tabRef.current) return;
    tabRef.current.setAttribute(
      "style",
      `height:${contentRef.current.clientHeight}px`
    );
  }, [contentRef.current, tabRef.current]);
  // 滚动事件【控制头部返回按钮是否显示】
  const scrollChange = (e) => {
    if (e?.y < -100) {
      setHeaderBackShow(false);
    } else {
      setHeaderBackShow(true);
    }
  };
  const [bannerData, setBannerData] = useState([]);
  const init = async () => {
    try {
      const res = await apiGetHotRank();
      if (res?.status) {
        setBannerData(res?.data);
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };
  useEffect(() => {
    init();
  }, []);
  const navList = [
    { id: 0, name: "热门点赞", },
    { id: 1, name: "热门购买", },
  ];
  const [tabIndex, setTabIndex] = useState(0);
  const [controllerSwiper, setControllerSwiper] = useState(null);
  // 监听swiper控制器和当前选项卡
  useEffect(() => {
    if (controllerSwiper) {
      controllerSwiper.slideTo(tabIndex);
    }
  }, [controllerSwiper, tabIndex]);
  return useMemo(() => (
    <div className="positioned-container hot-video">
      <HeaderBack
        stackKey={stackKey}
        leftIconIsLight
        title="视频热榜"
      />
      <div ref={contentRef} className="full-column">
        <ScrollArea
          ListData={bannerData}
          scrollChange={scrollChange}
        >
          <div style={{ paddingTop: '1.5rem' }}>
            {bannerData?.length && <BannerList list={bannerData} />}
          </div>
          <div ref={tabRef}>
            <TabsTwo
              themeLight
              navs={navList}
              currentIndex={tabIndex}
              onChange={(index) => {
                setTabIndex(index);
              }}
            />
            <Swiper
              className="default-swiper"
              initialSlide={type || 0}
              onSwiper={setControllerSwiper}
              onSlideChange={e => {
                setTabIndex(e.activeIndex);
              }}
            >
              {navList.map((item, index) => (
                <SwiperSlide key={`nav-item-${index}`}>
                  <List
                    show={tabIndex === index}
                    type={index}
                  />
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </ScrollArea>
      </div>
    </div>
  ), [backHeaderShow, bannerData, type, tabIndex]);
};

/**
 * banner列表
 * @param {*} props.list banner列表
 */
const BannerList = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <Swiper
        className="default-swiper"
        pagination
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
      >
        {list?.map((item, index) => (
          <SwiperSlide key={`SwiperSlide-${index}`}>
            <ClickBtn
              className="hot-video-head"
              onTap={() => handle(list, index)}
            >
              <div className="box">
                <div className="top-title">{item?.title}</div>
                <Simg src={item?.thumbImg} />
              </div>
              <div className="title">
                {item?.like || 0}位老铁在讨论
              </div>
            </ClickBtn>
          </SwiperSlide>
        ))}
      </Swiper>
    ) : <></>
  ), [list]);
};

/**
 * 列表
 * @param {boolean} props.show 是否显示列表
 * @param {number}  props.type 类型{0:热门点赞,1:热门购买,2:热门合集}
 */
const List = (props) => {
  const { show, type } = props;
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      let res = null;
      let tempList = [];
      switch (type) {
        case 1:
          res = await apiGetHotSale(params); // 热门购买
          tempList = res?.data || [];
          break;
        default:
          res = await apiGetHotLike(params); // 热门点赞
          tempList = res?.data || [];
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true)
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <ListHotVideoRank list={data} />
        </ScrollArea>
      ) : <NoData />
    )
  ), [loading, data, loadingMore]);
};
