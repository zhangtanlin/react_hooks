import React, { useEffect, useState, useMemo } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import ScrollArea from '../ScrollArea';
import HeaderBack from '../Header/HeaderBack';
import Simg from '../Simg';
import ClickBtn from '../ClickBtn';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import VideoShort from "../Video/VideoShort";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { ListTagVideoDetail } from "../List/Video";
import {
  apiSearchUploadList
} from '../../libs/http';
SwiperCore.use([Controller]);

// 发现-最新
export default (props) => {
  const { stackKey, } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const res = await apiSearchUploadList(params);
      if (res?.status) {
        const tempData = res?.data;
        if (params?.page === 1) {
          setData(tempData);
        } else {
          setData([...data, ...tempData]);
        }
        if (!tempData?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleNew}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        data?.length ? (
          <ScrollArea
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
          >
            <div className="public-padding">
              <ListTagVideoDetail list={data} />
            </div>
          </ScrollArea>
        ) : (<NoData />)
      )}
    </div>
  ), [loading, data, loadingMore]);
};

/**
 * banner列表
 * @param {*} props.list banner列表
 */
const BannerList = (props) => {
  const { list } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const handle = (list, index) => {
    if (!list?.length) return;
    const tempStackKey = `VideoShort-${new Date().getTime()}`;
    StackStore.dispatch({
      type: "push",
      payload: {
        name: 'VideoShort',
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            <VideoShort
              stackKey={tempStackKey}
              data={list}
              index={index}
            />
          </StackPage>
        ),
      },
    });
  };
  return useMemo(() => (
    list?.length ? (
      <Swiper
        className="default-swiper"
        pagination
        autoplay={{
          delay: 3000,
          disableOnInteraction: false,
        }}
      >
        {list?.map((item, index) => (
          <SwiperSlide key={`SwiperSlide-${index}`}>
            <ClickBtn
              className="hot-video-head"
              onTap={() => handle(list, index)}
            >
              <div className="box">
                <div className="top-title">{item?.title}</div>
                <Simg src={item?.thumbImg} />
              </div>
              <div className="title">
                {item?.like || 0}位老铁在讨论
              </div>
            </ClickBtn>
          </SwiperSlide>
        ))}
      </Swiper>
    ) : <></>
  ), [list]);
};

/**
 * 列表
 * @param {boolean} props.show 是否显示列表
 * @param {number}  props.type 类型{0:热门点赞,1:热门购买,2:热门合集}
 */
const List = (props) => {
  const { show, type } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params };
      let res = null;
      let tempList = [];
      switch (type) {
        case 1:
          res = await apiGetHotSale({ tempParam }); // 热门购买
          tempList = res?.data || [];
          break;
        default:
          res = await apiGetHotLike({ tempParam }); // 热门点赞
          tempList = res?.data || [];
          break;
      }
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempList);
        } else {
          setData([...data, ...tempList]);
        }
        if (!tempList?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true)
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      data?.length > 0 ? (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <ListHotVideoRank list={data} />
        </ScrollArea>
      ) : <NoData />
    )
  ), [loading, data, loadingMore]);
};
