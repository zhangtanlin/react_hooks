import React, { useEffect, useMemo, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Controller } from "swiper";
import "swiper/swiper.min.css";

import HeaderBack from "../Header/HeaderBack";
import ScrollArea from "../ScrollArea";
import Loading from "../Loading";
import Emit from "../../libs/eventEmitter";
import { TabsTwo } from '../Tab';
import { NoData } from "../NoData";
import { ListTagVideoDetail } from "../List/Video";
import { apiGetVideoByTag } from "../../libs/http";

SwiperCore.use([Controller]);

// 标签详情
export default props => {
  const { stackKey, tag } = props;
  const navList = [
    { id: 0, name: "最新", },
    { id: 1, name: "最热", }
  ];
  const [tabIndex, setTabIndex] = useState(0);
  const [controllerSwiper, setControllerSwiper] = useState(null);
  // 监听swiper控制器和当前选项卡
  useEffect(() => {
    if (controllerSwiper) {
      controllerSwiper.slideTo(tabIndex);
    }
  }, [controllerSwiper, tabIndex]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={tag}
      />
      <TabsTwo
        navs={navList}
        currentIndex={tabIndex}
        onChange={(index) => {
          setTabIndex(index);
        }}
      />
      <Swiper
        className="default-swiper"
        onSwiper={setControllerSwiper}
        onSlideChange={e => {
          setTabIndex(e.activeIndex);
        }}
      >
        {navList?.map((item, index) => (
          <SwiperSlide key={`home-tag-item-${index}`}>
            <List
              show={tabIndex === item?.id}
              type={index}
              tag={tag}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  ), [navList, tag, tabIndex]);
};

/**
 * 查询列表
 * @param {*} props.type 类型{0: 最新, 1: 最热}
 * @returns
 */
const List = props => {
  const { show, tag, type } = props;
  const [init, setInit] = useState(false); // 判定是否初次进入
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      let tempType = 'newest';
      switch (type) {
        case 1:
          tempType = 'hottest';
          break;
        default:
          tempType = 'newest';
          break;
      }
      const tempParam = {
        tag,
        type: tempType,
        ...params,
      };
      const res = await apiGetVideoByTag(tempParam);
      if (res.status) {
        if (params?.page === 1) {
          setData(res?.data || []);
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    if (show) {
      setInit(true)
    }
  }, [show]);
  useEffect(() => {
    if (init) {
      getData();
    }
  }, [init, params]);
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <ScrollArea
        ListData={data?.length}
        loadingMore={loadingMore}
        onScrollEnd={nextPage}
      >
        {data?.length > 0 ? (
          <div className="public-padding">
            <ListTagVideoDetail list={data} />
          </div>
        ) : <NoData />}
      </ScrollArea>
    )
  ), [loading, data, loadingMore]);
};
