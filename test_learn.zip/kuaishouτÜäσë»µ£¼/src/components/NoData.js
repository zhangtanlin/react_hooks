import React from "react";
import noData from "../resources/img/img_no_data.png";
import "../resources/css/no_data.less";

export const NoData = (props) => {
  const { text, guideText } = props;
  return (
    <div className="noData">
      <img src={noData} />
      <span>{text || "什么都没有，好空虚啊"}</span>
      {guideText && guideText()}
    </div>
  );
};

// 关注-头部-还没有关注的人
export const FollowHeaderNoData = () => (
  <div className="no-data-follow">
    <div className="info">
      <div className="title">
        您还没有关注的人哦~
      </div>
      <div className="subtitle">
        已经关注了？别着急，他们最近还没更新喃
      </div>
    </div>
    <div className="prompt">
      为您推荐部分优质用户
    </div>
  </div>
);
