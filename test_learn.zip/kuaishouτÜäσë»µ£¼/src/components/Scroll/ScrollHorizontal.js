import React, { useEffect, useRef, useState } from "react";
import "../../resources/css/scroll/scroll_horizontal.less";

import BScroll from "@better-scroll/core";
import { throttle } from "../../libs/utils";
import Emit from "../../libs/eventEmitter";

export default props => {
  const { children } = props;
  const scrollerRef = useRef(null);
  const [bscroll, setBscroll] = useState(null);
  useEffect(() => {
    setTimeout(() => {
      if (scrollerRef.current && !bscroll) {
        setBscroll(
          new BScroll(scrollerRef.current, {
            scrollY: false,
            scrollX: true,
            useTransition: true,
            click: true,
            probeType: 2
          })
        );
      } else if (bscroll) {
        bscroll.on(
          "scroll",
          throttle(() => {
            Emit.emit("isInViewPortEvent");
          }, 1000)
        );
      }
    }, 500);
    return () => {
      if (bscroll) {
        bscroll.destroy();
      }
    };
  }, [scrollerRef.current, bscroll]);
  return (
    <div className="top-nav-list swiper-no-swiping">
      <div
        ref={scrollerRef}
        className="horizontal_scroll"
      >
        <div className="top-slide-content">
          {children}
        </div>
      </div>
    </div>
  );
};
