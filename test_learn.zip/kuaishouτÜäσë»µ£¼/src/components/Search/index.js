import React, { useMemo, useState } from "react";
import "../../resources/css/search.less";

import HeaderBack from "../Header/HeaderBack";
import searchIcon from "../../resources/img/icon_search.png";
import Emit from "../../libs/eventEmitter";
import ClickBtn from "../ClickBtn";
import SearchIndex from "./Home";
import SearchResult from "./Result";
import Const from "../../libs/const";

// 搜索页
export default (props) => {
  const { stackKey } = props;
  const [params, setParams] = useState({
    // 搜索文本
    searchText: '',
    // 是否开始搜索
    isSearch: false,
  });
  // 搜索
  const handleSearch = (keyword) => {
    if (!keyword) return;
    try {
      const history = localStorage.getItem(
        Const.searchStorageKey,
      );
      if (!history) {
        localStorage.setItem(
          Const.searchStorageKey,
          keyword
        );
      } else {
        const tempArr = history.split(',');
        if (!tempArr.includes(keyword)) {
          if (tempArr.length > 9) {
            const tempCut = tempArr.slice(0, 9);
            tempCut.unshift(keyword);
            localStorage.setItem(
              Const.searchStorageKey,
              tempCut.join(',')
            );
          } else {
            localStorage.setItem(
              Const.searchStorageKey,
              `${keyword},${history}`
            );
          }
        }
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "保存关键字失败",
      });
    }
  };
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        center={() => (
          <div className="search-header-input">
            <img src={searchIcon} />
            <input
              value={params.searchText}
              disabled={params.isSearch}
              placeholder="可搜索用户/视频/喜好"
              onChange={({ target }) => {
                setParams((tempParams) => ({
                  ...tempParams,
                  searchText: target?.value
                }));
              }}
              onKeyUp={(e) => {
                if (e.key === 'Enter') {
                  handleSearch(params.searchText);
                  setParams((tempParams) => ({
                    ...tempParams,
                    isSearch: true
                  }));
                }
              }}
            />
          </div>
        )}
        right={() => (
          <ClickBtn
            className="back-header-btn"
            onTap={() => {
              handleSearch(params.searchText);
              setParams((tempParams) => ({
                ...tempParams,
                isSearch: !tempParams.isSearch
              }));
            }}
          >
            {params.isSearch ? "取消" : "搜索"}
          </ClickBtn>
        )}
      />
      {params.isSearch ? (
        <SearchResult
          show={params.isSearch}
          text={params.searchText}
        />
      ) : (
        <SearchIndex
          show={!params.isSearch}
          chooseTag={(keyword) => {
            handleSearch(keyword);
            setParams((tempParams) => ({
              ...tempParams,
              ...{
                searchText: keyword,
                isSearch: true,
              }
            }));
          }}
        />
      )}
    </div>
  ), [
    params,
  ]);
};
