import React, { useEffect, useMemo, useState } from "react";
import '../../resources/css/sheet/sheet_video_buy.less';

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import StackPage from "../StackPage";
import DiamondRecharge from '../User/DiamondRecharge';
import Recharge from '../User/Recharge';
import Loading from "../Loading";
import Emit from "../../libs/eventEmitter";
import BtnSheetVideoBuy from "../Btn/BtnSheetVideoBuy";
import VideoLong from "../Video/VideoLong";
import {
  apiBuyVideoByDiamond, // 钻石购买视频
  apiGetUserInfo, // 用户信息
} from "../../libs/http";

import iconTv from '../../resources/img/icon_tv_gray.png';
import iconPen from '../../resources/img/icon_pen_gray.png';

/**
 * 购买视频底部弹出框内容
 * @param {*} props.videoInfo 视频信息
 */
export default (props) => {
  const {
    videoInfo,
    onSuccess,
  } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    setLoading(false);
  }, []);
  // 初始化用户信息
  const initUserInfo = async () => {
    try {
      const res = await apiGetUserInfo();
      const tempObject = {
        ...res.data,
      }; // 字段说明参考userStore
      UserStore.dispatch({
        type: "replace",
        payload: tempObject,
      });
    } catch (error) {
      Emit.emit("showToast", {
        text: "刷新用户信息失败",
      });
    }
  };
  // 按钮点击事件{type:{0/null: 立即购买, 1: 充vip, 2: 充钻石,}}
  const handle = async (type) => {
    if (type === 1) {
      Emit.emit("showSheet", {
        _show: false,
      });
      const stackKey = `Recharge-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: 'Recharge',
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <Recharge stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    } else if (type === 2) {
      Emit.emit("showSheet", {
        _show: false,
      });
      const stackKey = `DiamondRecharge-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: 'DiamondRecharge',
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <DiamondRecharge stackKey={stackKey} />
            </StackPage>
          ),
        },
      });
    } else {
      try {
        const tempParams = { id: videoInfo?.id };
        const res = await apiBuyVideoByDiamond(tempParams);
        if (res?.status) {
          Emit.emit("showSheet", { _show: false, });
          Emit.emit("showToast", {
            text: res?.data?.msg || res?.msg || "视频购买成功",
            time: 3000
          });
          // 刷新用户信息
          initUserInfo();
          onSuccess && onSuccess();
          // 跳转长视频播放
          const stackKey = `VideoLong-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "VideoLong",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <VideoLong
                    stackKey={stackKey}
                    id={videoInfo?.id}
                  />
                </StackPage>
              ),
            },
          });
        } else {
          Emit.emit("showToast", {
            text: res?.data?.msg || '视频购买失败',
            time: 3000
          });
        }
      } catch (error) {
        Emit.emit("showToast", {
          text: '请求失败',
          time: 3000
        });
      }
    }
  };
  // 设置按钮
  const setBtn = () => {
    let text = '立即购买'; // 按钮文字
    let status = 0; // 状态{0/null: 立即购买, 1: 冲vip, 2: 冲钻石}
    if (videoInfo?.coins === 0) {
      if (!user?.isVV) {
        text = '充值VIP';
        status = 1;
      }
    }
    if (videoInfo?.coins > 0) {
      if (user?.coins < videoInfo?.coins) {
        text = '钻石不足，去充值';
        status = 2;
      }
    }
    return (
      <BtnSheetVideoBuy
        text={text}
        onTap={() => handle(status)}
      />
    );
  };
  return useMemo(() => (
    loading ? (
      <Loading show overSize={false} />
    ) : (
      <div className="sheet-video-buy">
        <div className="header" />
        <div className="content">
          {videoInfo?.like ? (
            <p className="title">
              <span className="special-text">
                {videoInfo?.coins || 0}
              </span>
              钻
            </p>
          ) : <></>}
          <div className="prompt">
            该视频为钻石视频，需要支付钻石解锁完整版
          </div>
          <div className="row">
            <div className="left">
              <div className="icon">
                <img src={iconTv} />
              </div>
              购买视频
            </div>
            <div className="right">
              {videoInfo?.title}
            </div>
          </div>
          <div className="row">
            <div className="left">
              <div className="icon">
                <img src={iconPen} />
              </div>
              视频作者
            </div>
            <div className="right">
              {videoInfo?.user?.nickname}
            </div>
          </div>
          {setBtn()}
        </div>
      </div>
    )
  ), [loading, videoInfo]);
};
