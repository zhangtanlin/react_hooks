/* eslint-disable arrow-body-style */
import axios from "axios";
import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useInView } from 'react-intersection-observer';
import CryptoData from "../libs/CryptoData";
import bgLogo from "../resources/img/bg_logo.jpg";
const inviewTimer = {};
export default (props) => {
  // noBg 不需要预加载图和背景 imgFinish图片准备完成
  const {
    className,
    src,
    noBg,
    imgFinish,
    objectFit,
    refreshScroll,
    alwaysShow,
    noThumb,
  } = props;
  const [src_state, setSrc] = useState(bgLogo);
  const imgRef = useRef(null);
  const [ref, inView] = useInView({
    threshold: 0,
    trackVisibility: true,
    delay: 100
  });
  useEffect(() => {
    inviewTimer[src] = null;
    return () => {
      delete inviewTimer[src];
    };
  }, []);
  useEffect(() => {
    if (refreshScroll && src_state !== bgLogo) {
      refreshScroll();
    }
  }, [src_state]);
  useLayoutEffect(() => {
    if (!imgRef.current) return;
    if ((!src && !alwaysShow) || (src_state && src_state != bgLogo)) return;
    if (!inView) {
      inviewTimer[src] && clearTimeout(inviewTimer[src]);
    } else {
      const setImg = () => {
        const arraybufferToBase64 = function (t) {
          return new Promise((function (e) {
            const n = new Blob([t]);
            const r = new FileReader();
            r.onload = function (t) {
              const n = t.target.result;
              const r = n.substring(n.indexOf(",") + 1);
              e(r);
            };
            r.readAsDataURL(n);
          }));
        };
        let SrcOfPwaDomain = src;
        let SrcOfPwaDomainThumb;
        if (src.lastIndexOf("?") + 1 == src.length) {
          SrcOfPwaDomain = SrcOfPwaDomain.substring(0, src.length - 1);
        }
        let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
        ext = ext === "jpg" ? "jpeg" : ext;
        if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
        if (!noThumb && "jpg,jpeg,png".indexOf(ext) != -1) {
          const _pr = 1 * (window.devicePixelRatio ?? 1) * 2.0;
          const filename = SrcOfPwaDomain.substring(0, SrcOfPwaDomain.lastIndexOf("."));
          if (imgRef?.current?.width * _pr < 180) {
            SrcOfPwaDomainThumb = `${filename}!180x0.${ext}`;
          }
          if (imgRef?.current?.width * _pr > 180 && imgRef?.current?.width * _pr < 600) {
            SrcOfPwaDomainThumb = `${filename}!360x0.${ext}`;
          }
          if (imgRef?.current?.width * _pr > 600 && imgRef?.current?.width * _pr < 900) {
            SrcOfPwaDomainThumb = `${filename}!720x0.${ext}`;
          }
          if (imgRef?.current?.width * _pr > 900) {
            SrcOfPwaDomainThumb = `${filename}.${ext}`;
          }
        }
        try {
          axios.get(
            noThumb ? SrcOfPwaDomain : SrcOfPwaDomainThumb,
            { responseType: 'arraybuffer' }
          ).then((res) => {
            arraybufferToBase64(res.data).then(base64str => {
              let decryptStr = CryptoData.DecryptImage(base64str);
              fetch(`data:image/${ext};base64,${decryptStr}`)
                .then((res) => res.blob())
                .then((blob) => {
                  setSrc(URL.createObjectURL(blob));
                  decryptStr = null;
                });
              imgFinish && imgFinish();
            });
          })
            .catch(() => {
              if (noThumb) return;
              axios.get(
                SrcOfPwaDomain,
                { responseType: 'arraybuffer' }
              ).then((res) => {
                arraybufferToBase64(res.data).then(base64str => {
                  let decryptStr = CryptoData.DecryptImage(base64str);
                  fetch(`data:image/${ext};base64,${decryptStr}`)
                    .then((res) => res.blob())
                    .then((blob) => {
                      setSrc(URL.createObjectURL(blob));
                      decryptStr = null;
                    });
                  imgFinish && imgFinish();
                });
              });
            });
        } catch (error) {
          console.warn(error);
        }
      };
      inviewTimer[src] = setTimeout(setImg, 400);
    }
  }, [imgRef, src, inView, alwaysShow, noThumb]);

  return useMemo(
    () => (
      <div
        ref={ref}
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {src_state ? (
          <RenderImage
            imgRef={imgRef}
            className={className}
            src_state={src_state}
            logoWhitePng={bgLogo}
            noBg={noBg}
            objectFit={objectFit}
          />
        ) : (
          <div
            style={{
              backgroundColor: '#ddd',
              width: '100%',
              height: '100%'
            }}
          />
        )}
      </div>
    ),
    [src_state]
  );
};

const RenderImage = (props) => {
  const { imgRef, className, src_state, logoWhitePng, noBg, objectFit } = props;
  useEffect(() => {
    return () => {
      URL.revokeObjectURL(src_state);
    };
  }, []);
  return (
    <img
      ref={imgRef}
      className={className}
      src={src_state}
      style={{
        objectFit:
          src_state === logoWhitePng
            ? "contain"
            : objectFit || "cover",
        width: src_state === logoWhitePng ? "60%" : "100%",
        height: src_state === logoWhitePng ? "60%" : "100%",
        opacity: noBg && src_state === logoWhitePng ? 0 : 1,
        transition: 'all 0.2s',
      }}
    />
  );
};
