import React, { useEffect, useState } from "react";
import axios from "axios";
import "../resources/css/splash.less";

import { apiGetHomeConfig, apiSetInvitateCode } from "../libs/http";
import { getQueryString } from '../libs/utils';
import CryptoData from "../libs/CryptoData";
import Emit from "../libs/eventEmitter";

export default props => {
  const [data, setData] = useState(null);
  const [seconed, setSeconed] = useState({ a: 5 });
  const [showBtn, setShowBtn] = useState(false);
  let timer;
  useEffect(() => {
    getImg();
    apiGetHomeConfig().then(res => {
      if (res?.status) {
        // 设置启屏页图片
        if (
          res?.data?.index_ads_thumb &&
          res?.data?.index_ads_url
        ) {
          setImg(
            res?.data?.index_ads_thumb,
            res?.data?.index_ads_url,
          );
        }
        // 获取渠道参数
        const affCode = getQueryString("aff_code");
        if (affCode) {
          apiSetInvitateCode({
            aff: affCode
          });
        }
      } else {
        Emit.emit("showToast", {
          text: res?.msg || res?.data?.msg || "整合接口请求失败",
        });
      }
    });
    return () => {
      if (timer) {
        clearInterval(timer);
      }
    };
  }, []);
  const setImg = (img, url) => {
    const SrcOfPwaDomain = img;
    const arraybufferToBase64 = function (t) {
      return new Promise((function (e) {
        const n = new Blob([t]);
        const r = new FileReader();
        r.onload = function (t) {
          const n = t.target.result;
          const r = n.substring(n.indexOf(",") + 1);
          e(r);
        };
        r.readAsDataURL(n);
      }));
    };
    let ext = SrcOfPwaDomain.substring(SrcOfPwaDomain.lastIndexOf(".") + 1);
    ext = ext === "jpg" ? "jpeg" : ext;
    if ("jpg,jpeg,png,gif".indexOf(ext) == -1) return;
    axios.get(
      SrcOfPwaDomain,
      { responseType: 'arraybuffer' }
    ).then(res => {
      arraybufferToBase64(res.data).then(base64str => {
        const decryptStr = CryptoData.DecryptImage(base64str);
        const _obj = {
          img: `data:image/${ext};base64,${decryptStr}`,
          url
        };
        localStorage.setItem("WELCOME_AD_CHA", JSON.stringify(_obj));
      });
    });
  };
  const getImg = () => {
    const _obj = localStorage.getItem("WELCOME_AD_CHA");
    if (_obj) {
      setData(JSON.parse(_obj));
      imgFinish();
    } else {
      props.history.replace("/home");
    }
  };
  const imgFinish = () => {
    setShowBtn(true);
    timer = setInterval(() => {
      seconed.a -= 1;
      setSeconed({ ...seconed });
      if (seconed.a == 0) {
        props.history.replace("/home");
        clearInterval(timer);
      }
    }, 1000);
  };
  return (
    <div className="container">
      {data && data.img && seconed.a != 0 && (
        <div className="welcome-ad">
          <img style={{ width: "100%", height: "100%" }} src={data.img} />
          <div
            onTouchEndCapture={() => {
              if (data.url) {
                window.open(data.url, "_blank");
              }
            }}
            className="welcome-ad-layer"
          />
          {showBtn && <div className="welcome-ad-btn">{seconed.a}</div>}
        </div>
      )}
    </div>
  );
};
