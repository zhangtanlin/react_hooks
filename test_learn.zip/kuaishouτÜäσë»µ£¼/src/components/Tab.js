import React, { useMemo } from "react";
import '../resources/css/tab.less';

import ClickBtn from "./ClickBtn";

// 右上角带原点的选项卡
export const Tabs = (props) => {
  const {
    navs,
    keyName,
    currentIndex,
    onChange,
    style,
  } = props;
  return useMemo(() => (
    <div className="tab" style={style}>
      {navs?.length ? (
        navs.map((item, index) => (
          <ClickBtn
            key={`tab-item-${index}`}
            onTap={() => onChange(index)}
            className={`tab-item ${currentIndex === index ? 'tab-active' : ''}`}
          >
            <div className="text-box">
              <span className="title">
                {keyName ? item[keyName] : item?.name}
              </span>
            </div>
          </ClickBtn>
        ))
      ) : <></>}
    </div>
  ), [style, navs, currentIndex]);
};

// 带横线的选项卡
export const TabsTwo = (props) => {
  const {
    themeLight = false,
    navs,
    keyName,
    currentIndex,
    onChange,
    style,
  } = props;
  return useMemo(() => (
    <div
      className={`tab-two ${themeLight ? 'theme-light' : ''}`}
      style={style}
    >
      {navs?.length ? (
        navs.map((item, index) => (
          <ClickBtn
            key={`tab-item-${index}`}
            onTap={() => onChange(index)}
            className={`tab-item ${currentIndex === index ? 'tab-active' : ''}`}
          >
            <div className="text">
              {keyName ? item[keyName] : item?.name}
            </div>
            <span className="mark-line" />
          </ClickBtn>
        ))
      ) : <></>}
    </div>
  ), [style, navs, currentIndex, themeLight]);
};
