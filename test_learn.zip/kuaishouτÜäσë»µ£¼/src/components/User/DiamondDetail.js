import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from '../NoData';
import { apiDiamondDetail } from '../../libs/http';

export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [loadMore, setLoadMore] = useState(true);
  const [page, setPage] = useState(1);
  const [list, setList] = useState([]);
  const getList = async () => {
    setLoadMore(true);
    try {
      const tempParam = { page, };
      const res = await apiDiamondDetail(tempParam);
      if (res?.status) {
        if (page === 1) {
          setList(res?.data);
        } else {
          setList([...list, ...res?.data]);
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadMore(false);
  };
  const loadMoreData = async () => {
    setPage((page) => (page + 1));
  };
  useEffect(() => {
    getList();
  }, [page]);

  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleDiamondDetail}
      />
      {
        loading ? (
          <Loading show overSize={false} />
        ) : (
          list?.length > 0 ? (
            <ScrollArea
              loadingMore={loadMore}
              onScrollEnd={loadMoreData}
            >
              {list.map((item, index) => (
                <div
                  key={`user-diamond-detail-item-${index}`}
                  className="user-diamond-detail-item"
                >
                  <div className="title">{item?.desc}</div>
                  <div className="subtitle">{item?.add_time_str?.split(' ')[0]}</div>
                </div>
              ))}
            </ScrollArea>
          ) : (
            <NoData />
          )
        )
      }
    </div>
  ), [loading, loadMore, list]);
};
