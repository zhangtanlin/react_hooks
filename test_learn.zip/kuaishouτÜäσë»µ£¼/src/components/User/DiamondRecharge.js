import React, { useEffect, useMemo, useState } from "react";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import HeaderBack from "../Header/HeaderBack";
import ScrollArea from "../ScrollArea";
import RechargeList from "./RechargList";
import ClickBtn from "../ClickBtn";
import Loading from '../Loading';
import BottomLayer from "../Sheet/BottomLayer";
import Login from "../Login";
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from "../NoData";
import { apiGetProductList, apiCreatePaying } from '../../libs/http';

import iconAlipay from '../../resources/img/icon_alipay.png';
import iconWechat from '../../resources/img/icon_wechat.png';
import iconUnionPay from '../../resources/img/icon_unionPay.png';
import iconVisa from '../../resources/img/icon_visa.png';
import iconDigital from '../../resources/img/icon_digital.png';

// 底部弹出框
export const SetPayWay = (props) => {
  const { show, list, onChange } = props;
  const [choosePayWay, setChoosePayWay] = useState({});
  // 重置支付选择和底部弹出框
  const reset = () => {
    setChoosePayWay({});
    onChange(false);
  };
  // 发送图形验证码
  const onSubmitImgCode = async (code) => {
    try {
      onSubmit(code);
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
  };
  // 创建订单
  let winRef;
  const origin = `${window.location.origin}/`;
  const onSubmit = async (code) => {
    if (!choosePayWay?.pw) {
      Emit.emit("showToast", {
        text: "请选择支付方式",
        time: 3000
      });
      return;
    }
    winRef = window.open(`${origin}waiting.html`, "_blank");
    try {
      const tempParam = {
        pw: choosePayWay?.pw,
        pt: "online",
        product_id: choosePayWay?.product_id,
        verify_code: code,
      };
      const res = await apiCreatePaying(tempParam);
      if (res?.status) {
        if (res?.data?.needVerifyCode) {
          Emit.emit("changeCaptcha", {
            show: true,
            onSubmit: async (code) => {
              await onSubmitImgCode(code);
            }
          }); // 判定需要使用图形验证码
          return;
        }
        reset();
        Emit.emit("changeAlter", {
          title: "温馨提示",
          content: (
            <div style={{ padding: '0 .4rem', textAlign: 'left', }}>
              1、充值高峰期间到账可能存在延迟，请稍作等待；<br />
              2、如遇充值多次失败、长时间未到账且消费金额未返还情况，请在“充值记录”中选择该订单说明情况，我们会尽快处理。
            </div>
          ),
          submitText: "知道了",
        });
        if (res?.data?.pay_type === "url" && res?.data?.pUrl) {
          winRef.location = res?.data?.pUrl;
        } else {
          Emit.emit("changeAlter", {
            _title: "温馨提示",
            _theme: 'black',
            _content: "获取支付地址失败",
            _submitText: "知道了",
            _notDouble: true,
          });
          winRef.location = `${origin}error.html`;
        }
      } else {
        Emit.emit("changeAlter", {
          title: "温馨提示",
          content: res?.msg || "请求支付失败",
          submitText: "知道了",
        });
      }
    } catch (error) {
      Emit.emit("changeAlter", {
        title: "温馨提示",
        content: "请求支付失败",
        submitText: "知道了",
      });
      winRef.location = `${origin}error.html`;
    }
  };
  return useMemo(() => (
    <BottomLayer
      show={show}
      onTap={() => {
        setChoosePayWay({});
        onChange(false);
      }}
      notList
    >
      <div className="user-recharge-layer">
        <div className="user-recharge-layer-head">选择支付方式</div>
        <div className="user-recharge-layer-content">
          <p className="user-recharge-layer-title">
            已选择{list[0]?.product_name || ''}
            <span className="color">¥{list[0]?.product_price || 0}</span>
          </p>
          {list?.length ? (
            list?.map((item, index) => (
              <ClickBtn
                key={`user-recharge-layer-row-${index}`}
                className="user-recharge-layer-row"
                onTap={() => {
                  setChoosePayWay(item);
                }}
              >
                <div className="user-recharge-layer-key">
                  <div className="icon-box">
                    <img src={item?.pay_way_icon} />
                  </div>
                  {item?.pay_way_name}
                </div>
                <div
                  className={`
                    user-recharge-layer-value
                    ${item?.pay_way_name === choosePayWay?.pay_way_name ? 'choosed' : ''}
                  `}
                />
              </ClickBtn>
            ))
          ) : (
            <Loading show overSize={false} />
          )}
          <ClickBtn
            className="user-public-btn"
            onTap={() => onSubmit()}
          >
            立即充值
          </ClickBtn>
        </div>
      </div>
    </BottomLayer>
  ), [show, list, choosePayWay]);
};

export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);
  const [descript, setDescript] = useState("");
  const [showLayer, setShowLayer] = useState(false);
  const [payWayList, setPayWayList] = useState([]);
  // 充值记录
  const handleRechargeList = () => {
    let tempName = 'Login';
    let tempStackKey = `Login-${new Date().getTime()}`;
    let tempPage = <Login stackKey={tempStackKey} />;
    if (user?.is_reg) {
      tempName = 'RechargeList';
      tempStackKey = `RechargeList-${new Date().getTime()}`;
      tempPage = <RechargeList stackKey={tempStackKey} />;
    }
    StackStore.dispatch({
      type: "push",
      payload: {
        name: tempName,
        element: (
          <StackPage
            stackKey={tempStackKey}
            key={tempStackKey}
            style={{ zIndex: stacks.length + 2 }}
          >
            {tempPage}
          </StackPage>
        ),
      },
    });
  };
  // 产品列表
  const getData = async () => {
    try {
      const tempParams = {
        type: 2,
      };
      const res = await apiGetProductList(tempParams);
      if (res?.status && res?.data?.list?.online?.length) {
        res?.data?.list?.online?.map(item => {
          const product_id = item?.id; // 产品id
          const product_name = item?.pname; // 产品名称
          const product_price = item?.p; // 新价格
          const product_price_old = item?.op; //老价格
          const product_price_type = item?.pt; // 类型
          if (item?.pw?.length) {
            item.pMethods = item?.pw?.map(item => {
              let pay_way_name = '';
              let pay_way_icon = '';
              let pw = '';
              switch (item) {
                case 'pa':
                  pay_way_name = '支付宝';
                  pay_way_icon = iconAlipay;
                  pw = item;
                  break;
                case 'pw':
                  pay_way_name = '微信';
                  pay_way_icon = iconWechat;
                  pw = item;
                  break;
                case 'ph':
                  pay_way_name = '花呗';
                  pay_way_icon = iconAlipay;
                  pw = item;
                  break;
                case 'pb':
                  pay_way_name = '银行卡';
                  pay_way_icon = iconUnionPay;
                  pw = item;
                  break;
                case 'pv':
                  pay_way_name = 'visa';
                  pay_way_icon = iconVisa;
                  pw = item;
                  break;
                case 'ps':
                  pay_way_name = '数字人民币';
                  pay_way_icon = iconDigital;
                  pw = item;
                  break;
                default:
                  pay_way_name = '';
                  pay_way_icon = '';
                  pw = '';
                  break;
              }
              const tempObj = {
                product_id,
                product_name,
                product_price,
                product_price_old,
                product_price_type,
                pay_way_name,
                pay_way_icon,
                pw,
              };
              return tempObj;
            });
          }
          return item;
        });
        setList(res?.data?.list?.online);
        setDescript(res?.data?.desc);
      } else {
        Emit.emit("showToast", {
          text: '获取产品列表失败'
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: '请求失败'
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    if (!user?.is_reg) {
      Emit.emit("changeAlter", {
        title: "温馨提示",
        content: (
          <div style={{margin: '0 .4rem'}}>
            请先注册登录后再充值，避免因账号丢失，导致会员或钻石无法找回
          </div>
          ),
        submitText: "确认",
        submit: async () => {},
      });
    }
    getData();
  }, []);
  // 选择产品
  const handleChooseProduct = (product) => {
    setPayWayList(product?.pMethods);
    setShowLayer(true);
  };
  return useMemo(() => (
    <div className="positioned-container user-diamond">
      <HeaderBack
        stackKey={stackKey}
        leftIconIsLight
        title={Const.titleDiamond}
        rightBtn={() => (
          <ClickBtn
            className="back-header-btn white"
            onTap={() => handleRechargeList()}
          >
            充值<br/>
            记录
          </ClickBtn>
        )}
      />
      <ScrollArea downRefresh={false}>
        <div className="user-diamond-content">
          <div className="user-diamond-head">
            <div className="title">钻石余额</div>
            <div className="text">{user?.coins || 0}</div>
            <div className="link"/>
          </div>
          <div className="user-diamond-active">
            <div className="user-diamond-title">在线充值</div>
            {loading ? (
              <Loading show />
            ) : (
              list?.length ? (
                <div className="user-diamond-list">
                  {list?.map((item, index) => (
                    <ClickBtn
                      key={`user-diamond-${index}`}
                      className="item"
                      onTap={() => handleChooseProduct(item)}
                    >
                      <div className="item-title">
                        {item?.pname}
                      </div>
                      <div className="item-subtitle">
                        ¥{item?.p}
                      </div>
                      <div className="item-descript">
                        {item?.description}
                      </div>
                    </ClickBtn>
                  ))}
                </div>
              ) : <NoData />
            )}
            <div className="user-diamond-subtitle">温馨提示</div>
            <div
              className="user-diamond-prompt"
              dangerouslySetInnerHTML={{
                __html: descript?.replaceAll('\n', '<br/>')
              }}
            />
          </div>
        </div>
      </ScrollArea>
      <SetPayWay
        list={payWayList}
        show={showLayer}
        onChange={setShowLayer}
      />
    </div>
  ), [user, loading, list, descript, showLayer, payWayList]);
};
