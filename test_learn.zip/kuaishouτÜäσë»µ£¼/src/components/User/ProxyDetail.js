import React, { useEffect, useMemo, useState } from "react";

import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import ScrollArea from "../ScrollArea";
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { NoData } from "../NoData";
import { apiProxyDetail } from '../../libs/http';
import { ListProxy } from "../List/Proxy";

// 代理详情
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const getData = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const res = await apiProxyDetail();
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data?.list || []);
        } else {
          setData([...data, ...res?.data?.list || []]);
        }
        if (!res?.data?.list?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.proxyDetail}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <ScrollArea
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          <div className="public-padding">
            {data?.length ? (
              <ListProxy list={data} />
            ) : <NoData />}
          </div>
        </ScrollArea>
      )}
    </div>
  ), [loading, data, loadingMore]);
};
