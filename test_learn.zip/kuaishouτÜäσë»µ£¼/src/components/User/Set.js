import React, { useMemo, useRef } from "react";

import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import StackPage from "../StackPage";
import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import ClickBtn from '../ClickBtn';
import Const from "../../libs/const";
import Emit from "../../libs/eventEmitter";
import ChangePwd from "../Login/ChangePwd";
import { ListUserSet } from "../List/User";
import {
  apiGetUserInfo,
  apiSetExchangeCode,
  apiSetInvitateCode,
  apiChangeUserInfo,
} from '../../libs/http';

// 设置
export default (props) => {
  const { stackKey } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const inviteCodeRef = useRef('');
  const exchangeCodeRef = useRef('');
  const nicknameRef = useRef('');
  const list = [
    {
      name: '账户/手机号',
      text: user?.username || '',
      status: 0,
      onTap: () => { }
    },
    {
      name: '填写兑换码',
      text: '',
      status: 1,
      onTap: () => {
        Emit.emit("changeAlter", {
          title: "兑换码",
          content: (
            <div
              className="user-input-box center"
              style={{ margin: '0 .4rem' }}
            >
              <input
                type="text"
                placeholder="请输入兑换码"
                onChange={({ target }) => {
                  exchangeCodeRef.current = target.value;
                }}
              />
            </div>
          ),
          submitText: "确定",
          submit: async () => {
            const reg = /^\s*$/g;
            if (reg.test(exchangeCodeRef.current)) {
              Emit.emit("showToast", {
                text: "兑换码不能为空",
                time: 3000
              });
              return;
            }
            try {
              const tempParam = { code: exchangeCodeRef.current, };
              const res = await apiSetExchangeCode(tempParam);
              if (res?.status) {
                Emit.emit("showToast", {
                  text: res?.msg || "兑换成功",
                });
                refresh();
              } else {
                Emit.emit("showToast", {
                  text: res?.msg || "兑换失败",
                });
              }
            } catch (error) {
              Emit.emit("showToast", { text: "请求失败" });
            }
            exchangeCodeRef.current = '';
          },
        });
      }
    },
    {
      name: '填写邀请码',
      text: user?.invite_by_code || '',
      status: 1,
      onTap: () => {
        if (user?.invite_by_code) {
          Emit.emit("showToast", {
            text: "已经填写过邀请码了～",
            time: 3000,
          });
        } else {
          Emit.emit("changeAlter", {
            title: "邀请码",
            content: (
              <div
                className="user-input-box center"
                style={{ margin: '0 .4rem' }}
              >
                <input
                  type="text"
                  placeholder="请输入邀请码"
                  onChange={({ target }) => {
                    inviteCodeRef.current = target.value;
                  }}
                />
              </div>
            ),
            submitText: "确定",
            submit: async () => {
              const reg = /^\s*$/g;
              if (reg.test(inviteCodeRef.current)) {
                Emit.emit("showToast", {
                  text: "邀请码不能为空",
                  time: 3000
                });
                return;
              }
              try {
                const tempParam = { aff: inviteCodeRef.current, };
                const res = await apiSetInvitateCode(tempParam);
                if (res?.status) {
                  UserStore.dispatch({
                    type: "replace",
                    payload: { invite_by_code: inviteCodeRef.current },
                  });
                  Emit.emit("showToast", { text: "绑定成功" });
                } else {
                  Emit.emit("showToast", { text: res?.msg || "绑定失败" });
                }
              } catch (error) {
                Emit.emit("showToast", { text: "请求失败" });
              }
              inviteCodeRef.current = '';
            },
          });
        }
      }
    },
    {
      name: '修改昵称',
      text: '',
      status: 1,
      onTap: () => {
        Emit.emit("changeAlter", {
          title: "修改昵称",
          content: (
            <div
              className="user-input-box center"
              style={{ margin: '0 .4rem' }}
            >
              <input
                type="text"
                placeholder="请输入昵称"
                onChange={({ target }) => {
                  nicknameRef.current = target.value;
                }}
              />
            </div>
          ),
          submitText: "确定",
          submit: async () => {
            const reg = /^\s*$/g;
            if (reg.test(nicknameRef.current)) {
              Emit.emit("showToast", {
                text: "昵称不能为空",
                time: 3000
              });
              return;
            }
            try {
              const tempParam = {
                nickname: nicknameRef.current,
              };
              const res = await apiChangeUserInfo(tempParam);
              if (res?.status) {
                UserStore.dispatch({
                  type: "replace",
                  payload: { nickname: nicknameRef.current },
                });
                Emit.emit("showToast", { text: "修改成功" });
              } else {
                Emit.emit(
                  "showToast",
                  { text: res?.msg || "修改失败" }
                );
              }
            } catch (error) {
              Emit.emit("showToast", { text: "请求失败" });
            }
            nicknameRef.current = '';
          },
        });
      }
    },
    {
      name: '修改密码',
      text: '',
      status: 1,
      onTap: () => {
        const stackKey = `ChangePwd-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "ChangePwd",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <ChangePwd stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      }
    },
  ];
  // 刷新用户信息
  const refresh = async () => {
    try {
      const res = await apiGetUserInfo();
      if (res?.status) {
        const tempObject = {
          ...res.data?.info,
        }; // 字段说明参考userStore
        UserStore.dispatch({
          type: "replace",
          payload: tempObject,
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
  };

  // 解除绑定
  const unBind = () => {
    Emit.emit("changeAlter", {
      title: "温馨提示",
      content: '确认解绑当前账号?',
      submitText: "确定",
      submit: async () => new Promise((resolve) => {
        window.localStorage.removeItem(Const.oauthId);
        UserStore.dispatch({
          type: "replace",
          payload: {},
        });
        window.location.reload();
        resolve();
      }),
    });
  };

  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleSet}
      />
      <ScrollArea>
        <div className="public-padding">
          <ListUserSet list={list} />
          {user?.is_reg ? (
            <ClickBtn
              className="user-public-btn"
              onTap={() => unBind()}
            >
              解除绑定
            </ClickBtn>
          ) : <></>}
        </div>
      </ScrollArea>
    </div>
  ), [user]);
};
