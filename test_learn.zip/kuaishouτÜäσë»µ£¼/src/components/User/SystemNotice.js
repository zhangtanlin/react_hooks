import React, { useEffect, useMemo, useState } from "react";

import HeaderBack from '../Header/HeaderBack';
import ScrollArea from "../ScrollArea";
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import { NoData } from '../NoData';
import { apiGetMsg } from '../../libs/http';

import iconSystemNotice from '../../resources/img/icon_system_notice.png';

export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const getList = async () => {
    if (params?.isAll) return;
    setLoadingMore(true);
    try {
      const tempParam = {
        ...params,
        type: 3,
      };
      const res = await apiGetMsg(tempParam);
      const tempData = [...res?.data, ...res?.data];
      if (res?.status) {
        if (params?.page === 1) {
          setData(tempData);
        } else {
          setData([...data, ...tempData]);
        }
        if (!tempData?.length) {
          setParams({
            ...params,
            isAll: true,
          });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getList();
  }, [params]);
  return useMemo(() => (
    <div className="positioned-container user-public-bg1">
      <HeaderBack
        stackKey={stackKey}
        title="系统通知"
        right={() => (
          <div style={{ width: '1.5rem' }} />
        )}
        style={{ background: '#fff' }}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        data?.length ? (
          <ScrollArea
            loadingMore={loadingMore}
            onScrollEnd={nextPage}
          >
            <MsgItem list={data} />
          </ScrollArea>
        ) : (<NoData />)
      )}
    </div>
  ), [loading, loadingMore, data]);
};

// 消息列表
const MsgItem = (props) => {
  const { list } = props;
  return useMemo(() => (
    <>
      {list?.length && (
        list.map((item, index) => (
          <div
            key={`msg-item-${index}`}
            className="user-msg-box"
          >
            <div className="title">{item?.created_at}</div>
            <div className="item">
              <img className="item-img" src={iconSystemNotice} />
              <div className="item-text">{item?.description}</div>
            </div>
          </div>
        ))
      )}
    </>
  ), [list]);
};
