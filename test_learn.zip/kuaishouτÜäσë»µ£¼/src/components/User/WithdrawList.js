import React, { useEffect, useMemo, useState } from "react";

import ScrollArea from "../ScrollArea";
import HeaderBack from '../Header/HeaderBack';
import Loading from '../Loading';
import Emit from "../../libs/eventEmitter";
import Const from "../../libs/const";
import { ListTable } from '../List/Table';
import { NoData } from '../NoData';
import { apiGetWithdrawList } from '../../libs/http';

// 提现记录
export default (props) => {
  const { stackKey } = props;
  const [loading, setLoading] = useState(true);
  const [params, setParams] = useState({
    page: 1,
    isAll: false,
  });
  const [data, setData] = useState([]);
  const [loadingMore, setLoadingMore] = useState(true);
  const headerList = [
    { name: '时间', value: 'created_at_str', },
    { name: '状态', value: 'status_str' },
    { name: '提现金额', value: 'amount' },
  ];
  const getData = async () => {
    if (params?.isAll) {
      return;
    }
    setLoadingMore(true);
    try {
      const tempParam = { ...params };
      const res = await apiGetWithdrawList(tempParam);
      if (res?.status) {
        if (params?.page === 1) {
          setData(res?.data || []);
        } else {
          setData([...data, ...res?.data]);
        }
        if (!res?.data?.length) {
          setParams({ ...params, isAll: true });
        }
      } else {
        Emit.emit("showToast", {
          text: "请求列表失败",
          time: 3000
        });
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
        time: 3000
      });
    }
    setLoading(false);
    setLoadingMore(false);
  };
  // 加载更多
  const nextPage = () => {
    if (!params?.isAll) {
      setParams((tempParam) => ({
        ...tempParam,
        page: tempParam?.page + 1
      }));
    }
  };
  useEffect(() => {
    getData();
  }, [params]);

  return useMemo(() => (
    <div className="positioned-container">
      <HeaderBack
        stackKey={stackKey}
        title={Const.titleWithdrawList}
      />
      <ListTable
        isHeader
        headerList={headerList}
        list={[]}
      />
      {loading ? (
        <Loading show overSize={false} />
      ) : (
        <ScrollArea
          ListData={data?.length}
          loadingMore={loadingMore}
          onScrollEnd={nextPage}
        >
          {data?.length ? (
            data.map((item, index) => (
              <ListTable
                key={`user-invite-${index}`}
                headerList={headerList}
                list={item}
              />
            ))
          ) : (<NoData />)}
        </ScrollArea>
      )}
    </div>
  ), [loading, data, loadingMore]);
};
