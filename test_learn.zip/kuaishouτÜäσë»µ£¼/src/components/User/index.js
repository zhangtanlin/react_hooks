import React, { useMemo } from "react";

import StackPage from "../StackPage";
import StackStore from "../../store/stack";
import UserStore from "../../store/user";
import ConfigStore from "../../store/config";
import ScrollArea from "../ScrollArea";
import ClickBtn from "../ClickBtn";
import SystemNotice from "./SystemNotice";
import Set from "./Set";
import Login from "../Login";
import HelpCenter from "../HelpCenter";
import Sale from "./Sale";
import Share from "./Share";
import DiamondRecharge from "./DiamondRecharge";
import Recharge from "./Recharge";
import Info from "./Info";
import Proxy from "./Proxy";
import App from "../App";
import Emit from "../../libs/eventEmitter";
import Simg from "../Simg";
import HeaderBack from "../Header/HeaderBack";
import { apiGetUserInfo } from "../../libs/http";

import iconVip from "../../resources/img/icon_vip.png";
import iconVipGray from "../../resources/img/icon_vip_gray.png";
import iconDiamond from "../../resources/img/icon_diamond.png";

import iconActiveIncome from "../../resources/img/icon_active_income.png";
import iconActiveMoney from "../../resources/img/icon_active_money.png";
import iconActiveMail from "../../resources/img/icon_mail.png";
import iconActiveGroup from "../../resources/img/icon_group.png";
import iconActiveSetting from "../../resources/img/icon_setting.png";
import iconActiveApp from "../../resources/img/icon_store.png";

import iconServerNotice from "../../resources/img/icon_server_notice.png";
import iconServerShare from "../../resources/img/icon_server_share.png";
import iconServerMarket from "../../resources/img/icon_market.png";

// 我的
export default (props) => {
  const { isVisible } = props;
  const [stacks] = StackStore.useGlobalState("stacks");
  const [user] = UserStore.useGlobalState("user");
  const [config] = ConfigStore.useGlobalState("config");
  // 横向布局(统计)
  const statisticsList = [
    {
      name: "系统通知",
      icon: iconServerNotice,
      descript: '',
      status: true,
      onTap: () => {
        const stackKey = `SystemNotice-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "SystemNotice",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <SystemNotice stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    }, {
      name: "分享无限看",
      icon: iconServerShare,
      descript: "",
      status: true,
      onTap: () => {
        const stackKey = `Share-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "Share",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <Share stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    }, {
      name: "钻石商城",
      icon: iconServerMarket,
      descript: `${user?.coins}钻石`,
      status: true,
      onTap: () => {
        const stackKey = `DiamondRecharge-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "DiamondRecharge",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <DiamondRecharge stackKey={stackKey} />
              </StackPage>
            ),
          },
        });
      },
    },
  ];

  const activeList = [
    {
      name: "我的购买",
      icon: iconActiveIncome,
      descript: '',
      status: true,
      onTap: () => {
        let tempName = 'Login';
        let tempStackKey = `Login-${new Date().getTime()}`;
        let tempPage = <Login stackKey={tempStackKey} />;
        if (user?.is_reg) {
          tempName = 'Sale';
          tempStackKey = `Sale-${new Date().getTime()}`;
          tempPage = <Sale stackKey={tempStackKey} />;
        }
        StackStore.dispatch({
          type: "push",
          payload: {
            name: tempName,
            element: (
              <StackPage
                stackKey={tempStackKey}
                key={tempStackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                {tempPage}
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "应用中心",
      icon: iconActiveApp,
      descript: '',
      status: true,
      onTap: () => {
        const stackKey = `App-${new Date().getTime()}`;
        StackStore.dispatch({
          type: "push",
          payload: {
            name: "App",
            element: (
              <StackPage
                stackKey={stackKey}
                key={stackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                <App stackKey={stackKey} title="钻石视频广场" />
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "推广赚钱",
      icon: iconActiveMoney,
      descript: '轻松月入上万',
      status: true,
      onTap: () => {
        let tempName = 'Login';
        let tempStackKey = `Login-${new Date().getTime()}`;
        let tempPage = <Login stackKey={tempStackKey} />;
        if (user?.is_reg) {
          tempName = 'Proxy';
          tempStackKey = `Proxy-${new Date().getTime()}`;
          tempPage = <Proxy stackKey={tempStackKey} />;
        }
        StackStore.dispatch({
          type: "push",
          payload: {
            name: tempName,
            element: (
              <StackPage
                stackKey={tempStackKey}
                key={tempStackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                {tempPage}
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "在线客服",
      icon: iconActiveMail,
      descript: '',
      status: true,
      onTap: () => {
        let tempName = 'Login';
        let tempStackKey = `Login-${new Date().getTime()}`;
        let tempPage = <Login stackKey={tempStackKey} />;
        if (user?.is_reg) {
          tempName = 'HelpCenter';
          tempStackKey = `HelpCenter-${new Date().getTime()}`;
          tempPage = <HelpCenter stackKey={tempStackKey} />;
        }
        StackStore.dispatch({
          type: "push",
          payload: {
            name: tempName,
            element: (
              <StackPage
                stackKey={tempStackKey}
                key={tempStackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                {tempPage}
              </StackPage>
            ),
          },
        });
      },
    },
    {
      name: "官方开车群",
      icon: iconActiveGroup,
      descript: '',
      status: true,
      onTap: () => {
        if (config?.tg) {
          window.open(config?.tg, '_blank');
          return;
        }
        Emit.emit("showToast", {
          text: "官方群未配置",
        });
      },
    },
    {
      name: "设置",
      icon: iconActiveSetting,
      descript: '',
      status: true,
      onTap: () => {
        let tempName = 'Login';
        let tempStackKey = `Login-${new Date().getTime()}`;
        let tempPage = <Login stackKey={tempStackKey} />;
        if (user?.is_reg) {
          tempName = 'Set';
          tempStackKey = `Set-${new Date().getTime()}`;
          tempPage = <Set stackKey={tempStackKey} />;
        }
        StackStore.dispatch({
          type: "push",
          payload: {
            name: tempName,
            element: (
              <StackPage
                stackKey={tempStackKey}
                key={tempStackKey}
                style={{ zIndex: stacks.length + 2 }}
              >
                {tempPage}
              </StackPage>
            ),
          },
        });
      },
    },
  ];
  // 下拉刷新
  const pullDownRefresh = async () => {
    try {
      const res = await apiGetUserInfo();
      const tempUserInfo = {
        ...res.data,
      }; // 字段说明参考userStore
      UserStore.dispatch({
        type: "replace",
        payload: tempUserInfo,
      });
    } catch (error) {
      Emit.emit("showToast", {
        text: "刷新用户信息失败",
      });
    }
  };
  // vip等级块
  const setVipLevelItem = () => {
    let bgClass = "";
    let title = "成为快手会员";
    let text = "每天领钻石";
    let btnText = '立即开通';
    if (user?.isVV) {
      bgClass = 'vip';
      title = `您已成为快手会员`;
      btnText = '立即续费';
      let tempExpired = '';
      if (user?.expiredStr) {
        tempExpired = user?.expiredStr.split(' ')[0];
      }
      switch (user?.vvLevel) {
        case 1:
        case '1':
          text = `您是月卡会员,到期时间${tempExpired}`;
          break;
        case 2:
        case '2':
          text = `您是季卡会员,到期时间${tempExpired}`;
          break;
        case 3:
        case '3':
          text = `您是年卡会员,到期时间${tempExpired}`;
          break;
        case 4:
        case "4":
          text = `您是永久会员`;
          break;
        default:
          text = "开通会员无限看片";
          break;
      }
    }
    return (
      <ClickBtn
        className={`user-member-box ${bgClass}`}
        onTap={() => {
          const stackKey = `Recharge-${new Date().getTime()}`;
          StackStore.dispatch({
            type: "push",
            payload: {
              name: "Recharge",
              element: (
                <StackPage
                  stackKey={stackKey}
                  key={stackKey}
                  style={{ zIndex: stacks.length + 2 }}
                >
                  <Recharge stackKey={stackKey} />
                </StackPage>
              ),
            },
          });
        }}
      >
        <div className="mark" />
        <div className="info">
          <span className="title">{title}</span>
          <span className="text">{text}</span>
        </div>
        <div className="btn">
          {btnText}
        </div>
      </ClickBtn>
    );
  };
  // 注册登录按钮-是否显示
  const setLoginRegistBtn = () => {
    if (user?.is_reg) {
      return <></>;
    }
    return (
      <HeaderBack
        left={() => <></>}
        right={() => (
          <div className="user-top">
            <ClickBtn
              className="user-public-btn small"
              onTap={() => {
                const tempStackKey = `Login-${new Date().getTime()}`;
                StackStore.dispatch({
                  type: "push",
                  payload: {
                    name: 'Login',
                    element: (
                      <StackPage
                        stackKey={tempStackKey}
                        key={tempStackKey}
                        style={{ zIndex: stacks.length + 2 }}
                      >
                        <Login stackKey={tempStackKey} />
                      </StackPage>
                    ),
                  },
                });
              }}
            >
              注册/登录
            </ClickBtn>
          </div>
        )}
      />
    );
  };
  // 用户信息
  const setUserInfo = () => (
    <div className="user-info-box">
      <div className="left">
        <ClickBtn
          className="user-avatar"
          onTap={() => {
            const stackKey = `Info-${new Date().getTime()}`;
            StackStore.dispatch({
              type: "push",
              payload: {
                name: "Info",
                element: (
                  <StackPage
                    stackKey={stackKey}
                    key={stackKey}
                    style={{ zIndex: stacks.length + 2 }}
                  >
                    <Info stackKey={stackKey} />
                  </StackPage>
                ),
              },
            });
          }}
        >
          <Simg src={user?.thumb} />
        </ClickBtn>
      </div>
      <div className="right">
        <div className="user-title">
          {user?.nickname}
        </div>
        <div className="user-subtitle-box">
          <span className="user-id-box">
            {user?.uid}
          </span>
          <div className="user-vip-box">
            <img
              src={user?.isVV ? iconVip : iconVipGray}
            />
          </div>
          <div className="user-diamonds-box">
            <img src={iconDiamond} />
            <span>{user?.level}</span>
          </div>
        </div>
      </div>
    </div>
  );
  return useMemo(() => (
    <div
      className={`
        positioned-container
        ${isVisible ? 'visible' : 'hide'}
      `}
    >
      {setLoginRegistBtn()}
      <ScrollArea pullDonRefresh={pullDownRefresh}>
        <div className="public-padding">
          {setUserInfo()}
          {setVipLevelItem()}
          <div className="user-row-box">
            {statisticsList.map((item, index) => (
              <ClickBtn
                key={`user-item-${index}`}
                className="user-item"
                onTap={item.onTap}
              >
                <div className="user-item-icon">
                  <img src={item.icon} />
                </div>
                <div className="user-item-title">
                  {item.name}
                </div>
                <div className="user-item-subtitle">
                  {item.descript}
                </div>
              </ClickBtn>
            ))}
          </div>
          <div className="user-list-box">
            {activeList.map((item, index) => (
              <ClickBtn
                key={`user-list-item-${index}`}
                className="user-item"
                onTap={() => item.onTap()}
              >
                <div className="user-item-left">
                  <img className="user-item-icon" src={item.icon} />
                  <div className="user-item-title">
                    {item.name}
                  </div>
                </div>
                <div
                  className={`
                    user-item-right
                    ${item?.status ? '' : 'bg-no'}
                  `}
                >
                  {item.descript}
                </div>
              </ClickBtn>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  ), [
    isVisible,
    user,
    statisticsList,
    activeList,
  ]);
};
