import React, { useEffect, useMemo, useRef, useState, } from "react";
import "../../resources/css/video/video_slide.less";

import Emit from "../../libs/eventEmitter";
import LoadingCircle from "../Loading/LoadingCircle";
import BtnVideoBack from "../Btn/BtnVideoBack";
import VideoPlayer from "./VideoPlayer";
import ClickBtn from "../ClickBtn";
import AvatarPlayer from "../Avatar/AvatarPlayer";
import { ListTagPlayer } from "../List/Tag";
import { apiGetLongVideoUrl } from "../../libs/http";
import {
  BtnPlayerLike,
  BtnPlayerShare,
  BtnPlayerComment,
} from "../Btn/BtnPlayer";

// 长视频播放器
export default (props) => {
  const { stackKey, id } = props;
  const playerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState('');
  const [paramsPlay, setParamsPlay] = useState({
    pause: false, // 视频是否暂停
    startPlay: true, // 是否开始播放
  });
  const getData = async () => {
    try {
      const tempParams = { id };
      const res = await apiGetLongVideoUrl(tempParams);
      if (res?.status) {
        setData(res?.data || {});
        setParamsPlay(() => ({
          ...paramsPlay,
          ...{
            pause: false,
            startPlay: true,
          }
        }));
        // if (playerRef?.current) {
        //   playerRef?.current?.play();
        // }
      }
    } catch (error) {
      Emit.emit("showToast", {
        text: "请求失败",
      });
    }
    setLoading(false);
  };
  useEffect(() => {
    getData();
  }, []);
  // 长视频播放器
  const LongPlayer = () => (
    data?.playURL || paramsPlay?.startPlay ? (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          position: "absolute",
          zIndex: 0,
          pointerEvents: "none",
        }}
      >
        <VideoPlayer
          loop
          auto
          videoRef={playerRef}
          isPlay={paramsPlay?.startPlay}
          src={data?.playURL}
        />
      </div>
    ) : <></>
  );
  // 视频信息
  const LongSlide = () => (
    <ClickBtn
      className="video-slide"
      style={{
        height: '90%',
      }}
      onTap={() => {
        if (paramsPlay.pause) {
          if (playerRef?.current) {
            playerRef?.current?.play();
          }
          setParamsPlay((tempParams) => ({
            ...tempParams,
            ...{
              pause: false,
            },
          }));
        } else {
          if (playerRef?.current) {
            playerRef?.current?.pause();
          }
          setParamsPlay((tempParams) => ({
            ...tempParams,
            ...{
              pause: true,
            },
          }));
        }
      }}
    >
      <div className="video-slide-info">
        <div className="video-slide-left">
          {data?.tags?.length > 0 ? (
            <ListTagPlayer
              list={data?.tags}
              onTap={() => {
                if (playerRef?.current) {
                  playerRef?.current?.pause();
                }
                setParamsPlay((tempParams) => ({
                  ...tempParams,
                  pause: true,
                }));
              }}
            />
          ) : <></>}
          <div className="name">
            @{data?.user?.nickname}
          </div>
          <p className="title">
            {data?.title}
          </p>
        </div>
        <div className="video-slide-right">
          <AvatarPlayer
            src={data?.user?.thumb}
            uid={data?.user?.uid}
            isFollow={data?.isFollowed}
            onInfoPage={() => {
              if (playerRef?.current) {
                playerRef?.current?.pause();
              }
              setParamsPlay((tempParams) => ({
                ...tempParams,
                pause: true,
              }));
            }}
          />
          <BtnPlayerLike
            id={data?.id}
            status={data?.isLiked}
            number={data?.like}
          />
          <BtnPlayerComment
            data={data}
          />
          <BtnPlayerShare
            data={data}
          />
        </div>
      </div>
    </ClickBtn>
  );
  return useMemo(() => (
    <div className="positioned-container black">
      <BtnVideoBack
        stackKey={stackKey}
        style={{
          top: '.75rem',
        }}
        onTap={() => {
          if (playerRef?.current) {
            playerRef?.current?.pause();
          }
          setLoading(true);
          setData({});
          setParamsPlay({
            pause: true,
            startPlay: false,
          });
        }}
      />
      {/* 播放器 */}
      {LongPlayer()}
      {/* 列表 */}
      {loading ? (
        <LoadingCircle show />
      ) : (
        LongSlide()
      )}
    </div>
  ), [
    loading,
    data,
    paramsPlay,
  ]);
};
