import React, { useMemo } from "react";
import "../../resources/css/video/video_slide.less";

import VideoPlayer from "./VideoPlayer";

// 长视频播放器
export default (props) => {
  const {
    playerRef,
    videoUrl,
  } = props;
  return useMemo(() => (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        position: "absolute",
        zIndex: 0,
        pointerEvents: "none",
      }}
    >
      {videoUrl ? (
        <VideoPlayer
          loop
          auto
          hideControls
          src={videoUrl}
          videoRef={playerRef}
        />
      ) : <></>}
    </div>
  ), [videoUrl,]);
};
