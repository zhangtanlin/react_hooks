import React, { useMemo } from "react";
import "../../resources/css/video/video_slide.less";

import VideoStore from "../../store/video";
import AvatarPlayer from "../Avatar/AvatarPlayer";
import Clickbtn from "../ClickBtn";
import GlobalVar from "../../libs/GlobalVar";
import { ListTagPlayer } from "../List/Tag";
import {
  BtnPlayerLike,
  BtnPlayerShare,
  BtnPlayerComment,
  BtnPlayerPlay
} from "../Btn/BtnPlayer";

/**
 * 滚动列表项
 * @param {*} item.onComment 评论
 * @param {*} item.onLongVideo 跳转长视频
 * @param {*} item.onShare 分享事件
 */
export default (props) => {
  const {
    playerRef,
    item,
  } = props;
  const [video] = VideoStore.useGlobalState("video");
  // 右侧信息列表
  const renderRight = () => (
    <div className="video-slide-right">
      <AvatarPlayer
        src={item?.user?.thumb}
        uid={item?.user?.uid}
        isFollow={item?.isFollowed}
      />
      <BtnPlayerLike
        id={item?.id}
        status={item?.isLiked}
        number={item?.like}
      />
      <BtnPlayerComment
        data={item}
      />
      <BtnPlayerShare data={item} />
    </div>
  );
  // 视频信息
  const renderInfo = () => (
    <div className="video-slide-left">
      {item?.tags?.length > 0 ? (
        <ListTagPlayer list={item?.tags} />
      ) : <></>}
      <div className="name">
        @{item?.user?.nickname}
      </div>
      <p className="title">
        {item?.title}
      </p>
    </div>
  );
  return useMemo(() => (
    <Clickbtn
      className="video-slide"
      onTap={() => {
        // 获取当前视频播放状态
        const tempVideoLongPause = GlobalVar?.videoLongPause;
        // 控制播放器
        if (tempVideoLongPause) {
          playerRef?.current?.play();
        } else {
          playerRef?.current?.pause();
        }
        // 渲染状态
        const tempVideoData = {
          videoLongPause: !tempVideoLongPause,
        };
        VideoStore.dispatch({
          type: "replace",
          payload: tempVideoData,
        });
        // 更改状态值
        GlobalVar.videoLongPause = !tempVideoLongPause;
      }}
    >
      <BtnPlayerPlay
        isShow={video?.videoLongPause}
      />
      <div className="video-slide-info">
        {renderInfo()}
        {renderRight()}
      </div>
    </Clickbtn>
  ), [
    video?.videoLongPause
  ]);
};
