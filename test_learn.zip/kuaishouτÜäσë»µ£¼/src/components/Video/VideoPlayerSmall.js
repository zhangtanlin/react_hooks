import React, { useRef, useMemo, useState, useEffect } from "react";
import Emit from "../../libs/eventEmitter";
import "../../resources/css/video/video_player_small.less";
import { BtnPlayerPlay, } from "../Btn/BtnPlayer";
import LoadingLine from "../Loading/LoadingLine";

/**
 * 视频播放器
 * @params durationChange 音视频数据发生变化时
 */
export default (props) => {
  const {
    videoRef = useRef(),
    src,
    thumb,
    autoPlay = false, // 自动播放
    loop = false,
    muted = false, // 是否静音(如果开启可以自动播放视频但是是静音的)
    showControls = false,
    style = {},
    onCanPlay,
    onPlay,
    onPause,
  } = props;
  const [loading, setLoading] = useState(true);
  const [pause, setPause] = useState(true); // 视频是否暂停

  useEffect(() => {
    console.log('set1', videoRef);
    console.log('set3', src);
    if (!videoRef?.current || !src) return;
    // 重新加载src指定的资源
    // videoRef?.current?.load();
    // 开始请求数据
    const handleLoadstart = () => {
      setLoading(true);
      console.log('开始请求数据');
    };
    // 正在请求数据
    const handleProgress = () => {
      console.log('正在请求数据');
    };
    // 延迟下载
    const handleSuspend = () => {
      console.log('延迟下载');
    };
    // 客户端主动终止下载(不是因为错误引起)
    const handleAbort = () => {
      console.log('客户端主动终止下载(不是因为错误引起)');
    };
    // 等待数据,并非错误
    const handleWaiting = () => {
      console.log('等待数据,并非错误');
    };
    // 网速失速
    const handleStalled = () => {
      console.log('网速失速', src);
      setLoading(true);
      Emit.emit("showToast", {
        text: "当前网络缓慢,请等待缓冲或刷新网络重试",
      });
    };
    // 渲染播放画面
    const handleLoadeddata = () => {
      console.log('渲染播放画面');
    };
    // 成功获取资源长度
    const handleLoadedmetadata = () => {
      console.log('成功获取资源长度');
      setLoading(false);
    };
    // 资源长度改变
    const handleDurationchange = () => {
      console.log('资源长度改变');
    };
    // 可以播放
    const handleCanPlay = () => {
      console.log('可以播放，但中途可能因为加载而暂停');
      setLoading(false);
      if (onCanPlay) {
        onCanPlay();
      }
    };
    // 播放
    const handlePlay = () => {
      console.log('播放');
      setPause(false);
      if (onPlay) {
        onPlay();
      }
    };
    // 播放
    const handlePlayed = () => {
      console.log('是否在播放');
    };
    // 暂停
    const handlePause = () => {
      console.log('暂停');
      setPause(true);
      if (onPause) {
        onPause();
      }
    };
    // 播放结束
    const handleEnded = () => {
      console.log('播放结束');
    };
    // 请求数据时遇到错误
    const handleError = () => {
      Emit.emit("showToast", {
        text: "请求数据时遇到错误",
      });
    };
    videoRef?.current?.addEventListener("loadstart", handleLoadstart, false);
    videoRef?.current?.addEventListener("progress", handleProgress, false);
    videoRef?.current?.addEventListener("suspend", handleSuspend, false);
    videoRef?.current?.addEventListener("abort", handleAbort, false);
    videoRef?.current?.addEventListener("waiting", handleWaiting, false);
    videoRef?.current?.addEventListener("stalled", handleStalled, false);
    videoRef?.current?.addEventListener("loadeddata", handleLoadeddata, false);
    videoRef?.current?.addEventListener("loadedmetadata", handleLoadedmetadata, false);
    videoRef?.current?.addEventListener("durationchange", handleDurationchange, false);
    videoRef?.current?.addEventListener("canplay", handleCanPlay, false);
    videoRef?.current?.addEventListener("play", handlePlay, false);
    videoRef?.current?.addEventListener("played", handlePlayed, false);
    videoRef?.current?.addEventListener("pause", handlePause, false);
    videoRef?.current?.addEventListener("ended", handleEnded, false);
    videoRef?.current?.addEventListener("error", handleError, false);
    return () => {
      console.log('remove', videoRef?.current);
      videoRef?.current?.removeEventListener("loadstart", handleLoadstart);
      videoRef?.current?.removeEventListener("progress", handleProgress);
      videoRef?.current?.removeEventListener("suspend", handleSuspend);
      videoRef?.current?.removeEventListener("abort", handleAbort);
      videoRef?.current?.removeEventListener("waiting", handleWaiting);
      videoRef?.current?.removeEventListener("stalled", handleStalled);
      videoRef?.current?.removeEventListener("loadeddata", handleLoadeddata);
      videoRef?.current?.removeEventListener("loadedmetadata", handleLoadedmetadata);
      videoRef?.current?.removeEventListener("durationchange", handleDurationchange);
      videoRef?.current?.removeEventListener("canplay", handleCanPlay);
      videoRef?.current?.removeEventListener("play", handlePlay);
      videoRef?.current?.removeEventListener("pause", handlePause);
      videoRef?.current?.removeEventListener("ended", handleEnded);
      videoRef?.current?.removeEventListener("error", handleError);
    };
  }, [videoRef, src]);

  return useMemo(() => (
    src ? (
      <div
        className="video-player-small"
        style={style}
      >
        {pause ? (
          <div className="video-play-btn">
            <BtnPlayerPlay />
          </div>
        ) : <></>}
        <video
          ref={videoRef}
          controls={showControls}
          autoPlay={autoPlay}
          loop={loop}
          muted={muted}
          poster={thumb}
          src={src}
          playsInline
        />
        {loading ? (
          <div className="loading-box">
            <LoadingLine />
          </div>
        ) : <></>}
      </div>
    ) : <></>
  ), [
    loading,
    videoRef,
    src,
    style,
    showControls,
    autoPlay,
    loop,
    muted,
    thumb,
    pause,
  ]);
};
