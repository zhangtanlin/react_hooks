import React, { useState, useEffect, useMemo, useRef, } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/swiper.min.css";
import "../../resources/css/video/video_slide.less";

import StackStore from "../../store/stack";
import StackPage from "../StackPage";
import UserStore from "../../store/user";
import Emit from "../../libs/eventEmitter";
import VideoLong from "../Video/VideoLong";
import ScrollVertical from "../Scroll/ScrollVertical";
import ClickBtn from "../ClickBtn";
import AvatarPlayer from "../Avatar/AvatarPlayer";
import SheetVideoBuy from "../Sheet/SheetVideoBuy";
import BtnVideoBack from "../Btn/BtnVideoBack";
import VideoPlayerSmall from "./VideoPlayerSmall";
import { NoData } from "../NoData";
import { ListTagPlayer } from "../List/Tag";
import { AlertVip } from "../Card/CardAlert";
import {
  BtnPlayerLike,
  BtnPlayerShare,
  BtnPlayerComment,
  BtnPlayerPlay,
} from "../Btn/BtnPlayer";

import bgVideo from "../../resources/img/bg_video.png";
import videoDetailIcon from "../../resources/img/icon_play_small_white.png";
import coinIcon from "../../resources/img/icon_diamond_yellow.png";

/**
 * 短视频播放器
 * @param {string} props.stackKey 页面key当有返回按钮时，用以返回上一级页面
 * @param {string} props.data 数据列表
 * @param {string} props.index 展示当前列表里面的第几个
 * @param {string} props.params 请求参数
 * @param {string} props.onParams 请求下一页数据,传递参数给父组件
 */
export default (props) => {
  const {
    stackKey,
    data,
    index,
  } = props;
  const [user] = UserStore.useGlobalState("user");
  const [stacks] = StackStore.useGlobalState("stacks");
  const [loading, setLoading] = useState(true);
  const playerRef = useRef();
  const [list, setList] = useState([]);
  const [paramsPlay, setParamsPlay] = useState({
    url: '', // 视频播放地址
    currentIndex: 0, // 当前展示的序列号
  });
  const [pause, setPause] = useState(true); // 视频是否暂停

  useEffect(() => {
    if (data?.length) {
      setList(data);
      setParamsPlay({
        url: data[index].playURL,
        currentIndex: index,
      });
    }
  }, [data]);



  // 监听是否暂停
  useEffect(() => {
    if (!playerRef?.current) return;
    // 暂停方法
    const handlePause = () => {
      playerRef?.current?.pause();
    }
    // 播放方法
    const handlePlay = async () => {
      const promisePlayer = await playerRef?.current?.play();
      if (promisePlayer) {
        promisePlayer.then(() => {
          // 继续播放
        });
      }
    }
    if (pause) {
      handlePause();
    } else {
      handlePlay();
    }
  }, [pause,]);

  // 短视频播放器
  const ShortPlayer = () => (
    paramsPlay?.url ? (
      <div className="feature-video-player">
        <VideoPlayerSmall
          autoPlay
          loop
          videoRef={playerRef}
          src={paramsPlay?.url}
        />
      </div>
    ) : <></>
  );

  // 短视频swiper
  const ShortSwiper = () => (
    <div className="feature-swiper">
      {list?.length ? (
        <Swiper
          className="default-swiper"
          noSwipingClass="swiper-no-swiping"
          direction="vertical"
          initialSlide={index}
          onSlideChange={(e) => {
            setParamsPlay((tempParams) => ({
              ...tempParams,
              ...{
                url: data[e?.activeIndex].playURL,
                currentIndex: e?.activeIndex,
              },
            }));
          }}
        >
          {list?.map((item, index) => (
            <SwiperSlide key={`video-slide-${index}`}>
              {ShortSlide(item)}
            </SwiperSlide>
          ))}
        </Swiper>
      ) : <NoData />}
    </div>
  );

  // 短视频slider
  const ShortSlide = (item) => (
    <ClickBtn
      className="video-slide"
      onTap={() => {
        console.log('pause22', pause)
        // setPause(!pause);
        setPause((tempPause) => (!tempPause));
        // if (pause) {
        //   handlePlay();
        // } else {
        //   handlePause();
        // }
      }}
    >
      <div className="video-slide-info">
        <div className="video-slide-left">
          {item?.tags?.length > 0 ? (
            <ListTagPlayer
              list={item?.tags}
              onTap={() => {
                setPause(true);
              }}
            />
          ) : <></>}
          <div className="name">
            @{item?.user?.nickname}
          </div>
          <p className="title">
            {item?.title}
          </p>
          <ClickBtn
            className="bottom"
            stopPropagation
            onTap={() => handleLongVideo(item)}
          >
            {!!item?.coins && (
              <div className="coin">
                <img src={coinIcon} />
                {item?.coins}
              </div>
            )}
            {item?.hasLongVideo ? (
              <div className="time">
                <span>
                  <img src={videoDetailIcon} />
                  {user?.isVip ? "观看完整版" : "预览10秒,充值VIP观看完整版"}
                </span>
                {(
                  item?.duration &&
                  item?.duration > 10 &&
                  item?.durationStr != 0
                ) ? (
                  <span>{item?.durationStr}</span>
                ) : <></>}
              </div>
            ) : <></>}
          </ClickBtn>
        </div>
        <div className="video-slide-right">
          <AvatarPlayer
            src={item?.user?.thumb}
            uid={item?.user?.uid}
            isFollow={item?.isFollowed}
            onInfoPage={() => {
              setPause(true);
            }}
          />
          <BtnPlayerLike
            id={item?.id}
            status={item?.isLiked}
            number={item?.like}
          />
          <BtnPlayerComment
            data={item}
          />
          <BtnPlayerShare
            data={item}
          />
        </div>
      </div>
    </ClickBtn>
  );

  // 跳转长视频
  const handleLongVideo = (videoInfo) => {
    if (!videoInfo?.id) return;
    setPause(true);
    // 已经购买+vip观看免费视频
    if (
      videoInfo?.hasBuy ||
      (
        user?.isVV &&
        videoInfo?.coins === 0
      )
    ) {
      const stackKey = `VideoLong-${new Date().getTime()}`;
      StackStore.dispatch({
        type: "push",
        payload: {
          name: "VideoLong",
          element: (
            <StackPage
              stackKey={stackKey}
              key={stackKey}
              style={{ zIndex: stacks.length + 2 }}
            >
              <VideoLong
                stackKey={stackKey}
                id={videoInfo?.id}
              />
            </StackPage>
          ),
        },
      });
      return;
    }
    // 钻石视频
    if (videoInfo?.coins > 0) {
      Emit.emit("showSheet", {
        _show: true,
        _content: (
          <SheetVideoBuy
            videoInfo={videoInfo}
            onSuccess={() => {
              let tempList = list;
              if (tempList?.length) {
                tempList.map((item, index) => {
                  if (index === paramsPlay.currentIndex) {
                    item.hasBuy = true;
                  }
                })
              }
              setList(tempList);
            }}
          />
        ),
        _contentStyle: {
          background: "transparent",
        },
      });
      return;
    }
    // 免费视频
    if (
      videoInfo?.coins === 0 &&
      !user?.isVV
    ) {
      Emit.emit(
        "changeDialog",
        {
          _show: true,
          _children: () => (
            <AlertVip />
          )
        },
      );
      return;
    }
  };
  return useMemo(() => (
    <div
      className="positioned-container black"
      style={{
        background: `center/cover no-repeat url("${bgVideo}")`,
      }}
    >
      <BtnVideoBack
        stackKey={stackKey}
        isLight
        onTap={() => {
          setPause(true);
        }}
      />
      {/* 播放器和轮播 */}
      <div className="feature-content">
        {ShortPlayer()}
        {ShortSwiper()}
      </div>
      {/* 广告 */}
      {(
        list?.length > 0 &&
        list[0].hotAds?.length > 0
      ) ? (
        <ScrollVertical
          list={list[0].hotAds}
          height={1.36}
          type={1}
          onTap={() => {
            setPause(true);
          }}
        />
      ) : <></>}
    </div>
  ), [
    loading,
    list,
    paramsPlay,
    pause,
  ]);
};
