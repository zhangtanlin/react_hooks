import React, { useMemo, } from "react";

import VideoStore from "../../store/video";
import VideoPlayer from "./VideoPlayer";
import Globalvar from "../../libs/GlobalVar";

import bgVideo from "../../resources/img/bg_video.png";

/**
 * 渲染视频播放器
 * @param {} videoUrl 视频播放地址
 */
export default (props,) => {
  const {
    playerRef,
  } = props;
  const [video] = VideoStore.useGlobalState("video");
  return useMemo(() => (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        background: `center/cover no-repeat url(${bgVideo})`,
        position: "absolute",
        zIndex: 0,
        pointerEvents: "none",
      }}
    >
      {!video?.videoUrl ? (
        <></>
      ) : (
        <VideoPlayer
          style={{ zIndex: 1, }}
          loop
          auto
          hideControls
          videoRef={playerRef}
          src={video?.videoUrl}
          durationChange={() => {
            if (Globalvar?.videoLoading) {
              Globalvar.videoLoading = false;
              // 全局更改状态并渲染
              const tempVideoData = {
                videoLoading: false,
              };
              VideoStore.dispatch({
                type: "replace",
                payload: tempVideoData,
              });
            }
          }}
        />
      )}
    </div>
  ), [
    video?.videoUrl,
    video?.videoLoading,
  ]);
};
