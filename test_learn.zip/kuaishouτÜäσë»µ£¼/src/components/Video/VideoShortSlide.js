import React, { useMemo } from "react";
import "../../resources/css/video/video_slide.less";

import UserStore from "../../store/user";
import VideoStore from "../../store/video";
import AvatarPlayer from "../Avatar/AvatarPlayer";
import ClickBtn from "../ClickBtn";
import GlobalVar from "../../libs/GlobalVar";
import { ListTagPlayer } from "../List/Tag";
import {
  BtnPlayerLike,
  BtnPlayerShare,
  BtnPlayerComment,
  BtnPlayerPlay,
} from "../Btn/BtnPlayer";

import videoDetailIcon from "../../resources/img/icon_play_small_white.png";
import coinIcon from "../../resources/img/icon_diamond_yellow.png";

/**
 * 滚动列表项
 * @param {*} item.onComment 评论
 * @param {*} item.onLongVideo 跳转长视频
 * @param {*} item.onShare 分享事件
 */
export default (props,) => {
  const {
    playerRef,
    item,
    onLongVideo,
  } = props;
  const [user] = UserStore.useGlobalState("user");
  const [video] = VideoStore.useGlobalState("video");
  // 右侧信息列表
  const renderRight = () => (
    <div className="video-slide-right">
      <AvatarPlayer
        src={item?.user?.thumb}
        uid={item?.user?.uid}
        isFollow={item?.isFollowed}
        playerRef={playerRef}
      />
      <BtnPlayerLike
        id={item?.id}
        status={item?.isLiked}
        number={item?.like}
        playerRef={playerRef}
      />
      <BtnPlayerComment
        data={item}
        playerRef={playerRef}
      />
      <BtnPlayerShare
        data={item}
        playerRef={playerRef}
      />
    </div>
  );
  // 如果时常存在就显示，不存在就不显示
  const renderDurationStr = (sec, duration) => {
    if (sec && sec > 10 && duration != 0) {
      return <span>{duration}</span>;
    }
    return <span />;
  };
  // 视频信息
  const renderInfo = () => (
    <div className="video-slide-left">
      {item?.tags?.length > 0 ? (
        <ListTagPlayer list={item?.tags} />
      ) : <></>}
      <div className="name">
        @{item?.user?.nickname}
      </div>
      <p className="title">
        {item?.title}
      </p>
      <div className="bottom">
        {!!item?.coins && (
          <ClickBtn
            className="coin"
            onTap={onLongVideo}
          >
            <img src={coinIcon} />
            {item?.coins}
          </ClickBtn>
        )}
        {item?.hasLongVideo ? (
          <ClickBtn
            className="time"
            onTap={onLongVideo}
          >
            <span>
              <img src={videoDetailIcon} />
              {user?.isVip ? "观看完整版" : "预览10秒,充值VIP观看完整版"}
            </span>
            {renderDurationStr(
              item?.duration,
              item?.durationStr,
            )}
          </ClickBtn>
        ) : <></>}
      </div>
    </div>
  );
  return useMemo(() => (
    <ClickBtn
      className="video-slide"
      onTap={() => {
        // 获取当前视频播放状态
        const tempVideoPause = GlobalVar?.videoPause;
        // 控制播放器
        if (tempVideoPause) {
          playerRef?.current?.play();
        } else {
          playerRef?.current?.pause();
        }
        // 渲染状态
        const tempVideoData = {
          videoPause: !tempVideoPause,
        };
        VideoStore.dispatch({
          type: "replace",
          payload: tempVideoData,
        });
        // 更改状态值
        GlobalVar.videoPause = !tempVideoPause;
      }}
    >
      <BtnPlayerPlay
        isShow={video?.videoPause}
      />
      <div className="video-slide-info">
        {renderInfo()}
        {renderRight()}
      </div>
    </ClickBtn>
  ), [
    video?.videoPause,
    video?.videoLoading,
  ]);
};
