import { createStore } from 'react-hooks-global-state';
import { formatPhone } from "../libs/utils";

const initialState = {
  user: {
    aff_code: "", // 我的推广码
    auth_level: 0, // 未知
    auth_status: 0, // 未知
    avatar_url: "", // 头像
    birthday: "", // 未知
    can_watch: 0, // 未知
    chat_uid: "", // 未知
    coins: 0, // 未知
    coins_total: 0, // 未知
    consumption: 0, // 未知
    exp: 0, // 未知
    expired_at: 0, // vip过期日期(是vip才会有vip过期日期)
    expired_str: "", // 未知
    fabulous_count: 0, // 获赞数
    fans_count: 0, // 自己的粉丝数
    followed_count: 0, // 自己关注人数
    invite_by_code: "", // 被邀请码
    invited_by: '', // 被邀请码
    invited_num: 0, // 被邀请数
    isCanWatchLive: true, // 未知
    isRealUser: true, // 未知
    isRisk: 0, // 未知
    isUsedLiveList: false, // 未知
    is_attention: 0, // 未知
    is_recommend: 0, // 未知
    is_reg: 0, // 是否注册
    isVV: 0, // 是否是vip
    lastactivity: 0, // 未知
    level: 0, // 未知
    likes_count: 0, // 未知
    live_count: 0, // 未知
    message_tip: 0, // 我的通知 {0:没有}
    my_ticket_number: 0, // 观影券数据量
    new_topic_reply: 0, // 未知
    nickname: "", // 昵称
    person_signnatrue: "暂无", // 个性签名
    role_id: 8, // 未知
    role_type: "normal", // 未知
    score: 0, // 未知
    score_total: 0, // 未知
    sexType: 0, // 未知
    share: 0, // 未知
    share_text: "", // 分享文本
    share_url: "", // 分享链接
    today_mv_score: 0, // 今日视频收入
    today_tui_coins: 0, // 今日推广收入
    token: "", // token
    topic_cfg: {}, // 未知
    total_tui_coins: "0.00", // 未知
    tui_coins: "0.00", // 未知
    uid: '', // 未知
    user_activation_key: "", // 未知
    username: "", // 登陆之后的用户名（用来判定是否登陆）
    validate: 0, // 未知
    videos_count: 0, // 作品总数
    vip_level: 0, // vip等级(是vip才会有vip等级)
    votes: "0.00", // 未知
    votes_total: "0.00", // 未知
    watch_count: 0, // 观看次数
    zbInfo: {
      app_id: "", // 直播-当前appid
      app_key: "", // 直播-当前appkey
      app_name: "", // 直播appname
      base_api_url: "", // 直播访问地址
      branch_channel_id: "1",
      download_url: "",
      game_channel: "1",
      report_url: "",
      upload_url: "",
    }, // 直播-当前用户信息
    zbToken: "", // 直播-token
    zbUid: "", // 直播-uid
  },
};

const reducer = (state, action) => {
  if (action.type === 'replace') {
    let newPayload = action?.payload;
    // 处理电话号码
    if (newPayload?.username) {
      newPayload = {
        ...newPayload,
        ...{
          _phone: formatPhone(newPayload?.username),
        }
      };
    }
    return { ...state, user: { ...state.user, ...newPayload } };
  }
  return state;
};

const UserStore = createStore(reducer, initialState);

export default UserStore;
