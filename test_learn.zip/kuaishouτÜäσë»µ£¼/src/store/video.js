import { createStore } from 'react-hooks-global-state';

// swiper+视频播放器
const initialState = {
  video: {
    // 短视频-视频播放器是否暂停(状态)
    videoPause: true,
    // 短视频-视频是否加载中
    videoLoading: true,
    // 短视频-视频url
    videoUrl: '',
    // 短视频-当前视频是列表视频的第几个(一般用在其他页面跳转到短视频播放页,用以确认播放/展示第几个序列号)
    videoSwiperIndex: 0,

    // 长视频-视频播放器是否暂停(状态)
    videoLongPause: false,
  },
};

const reducer = (state, action) => {
  if (action.type === 'replace') {
    return {
      ...state,
      video: {
        ...state.video,
        ...action?.payload,
      }
    };
  }
  return state;
};

const VideoStore = createStore(reducer, initialState);

export default VideoStore;
