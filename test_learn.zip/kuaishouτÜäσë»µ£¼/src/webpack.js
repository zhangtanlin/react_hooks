import SassPlugin from '@pawjs/sass/webpack';
import LessPlugin from '@pawjs/less/webpack';
import SrcsetPlugin from '@pawjs/srcset/webpack';
import ImageOptimizer from '@pawjs/image-optimizer/webpack';

export default class ProjectWebpack {
  constructor({ addPlugin }) {
    // Add sass compiler to the project
    const optimizerOptions = {
      supportedEnv: [
        'production',
      ],
      configLabel: 'MEDIUM_QUALITY',
    };
    addPlugin(new ImageOptimizer(optimizerOptions));
    addPlugin(new SrcsetPlugin());
    addPlugin(new LessPlugin());
    addPlugin(new SassPlugin());
  }
}
